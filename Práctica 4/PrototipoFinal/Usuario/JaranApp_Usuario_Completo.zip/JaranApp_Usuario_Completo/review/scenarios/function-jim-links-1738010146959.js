(function(window, undefined) {

  var jimLinks = {
    "4ffd4d39-045b-4131-a48d-1fe27d8bd287" : {
      "Button_1" : [
        "d11a9252-a8fb-4d39-8501-7bf5e7010e39"
      ],
      "Path_5" : [
        "d11a9252-a8fb-4d39-8501-7bf5e7010e39"
      ],
      "Path_6" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_7" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_9" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ]
    },
    "1189be83-d238-44ef-8484-e2741b9b1679" : {
      "Button_1" : [
        "667faad0-092e-47b1-a674-178de97be8c5"
      ],
      "Path_5" : [
        "667faad0-092e-47b1-a674-178de97be8c5"
      ],
      "Path_6" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_7" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_9" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ]
    },
    "449ef3fa-cb12-499c-850b-9d235faaa5da" : {
      "Path_5" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_6" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_8" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Path_9" : [
        "d11a9252-a8fb-4d39-8501-7bf5e7010e39"
      ]
    },
    "4fd198ed-59ae-4a63-9437-39f7e5c081b1" : {
      "Path_3" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_4" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_6" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Hotspot_1" : [
        "667faad0-092e-47b1-a674-178de97be8c5"
      ]
    },
    "fbf73125-c0bb-4e96-b775-5131ea7dda66" : {
      "Path_3" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_4" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_6" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Path_1" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ]
    },
    "a7f04495-14b9-4cff-a1ac-d7e5eba837e6" : {
      "Rectangle_6" : [
        "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"
      ],
      "Path_8" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Button_1" : [
        "667faad0-092e-47b1-a674-178de97be8c5"
      ],
      "Image_8" : [
        "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"
      ],
      "Text_9" : [
        "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"
      ],
      "Text_14" : [
        "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"
      ],
      "Path_4" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_5" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_7" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Path_16" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ],
      "Path_17" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ],
      "Path_18" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ],
      "Path_19" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ],
      "Path_20" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ]
    },
    "57adc1c3-aa32-4e3d-9bf2-98b361db73cb" : {
      "Path_3" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_4" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_6" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Path_1" : [
        "667faad0-092e-47b1-a674-178de97be8c5"
      ]
    },
    "1149f5ba-d63e-4481-b8be-3fd1f69a47a6" : {
      "Path_3" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_4" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_6" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Path_1" : [
        "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"
      ],
      "Button_1" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ]
    },
    "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc" : {
      "Rectangle_10" : [
        "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"
      ],
      "Rectangle_11" : [
        "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"
      ],
      "Path_17" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Path_7" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_8" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_11" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ]
    },
    "32231785-f960-4fea-9baf-00b50be60690" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_117" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "1b6cf767-c424-42c6-abc7-a45fd636baa9" : {
      "Path_1" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_11" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_12" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_14" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Text_1" : [
        "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"
      ],
      "Text_2" : [
        "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"
      ],
      "Text_12" : [
        "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"
      ],
      "Text_13" : [
        "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"
      ]
    },
    "d11a9252-a8fb-4d39-8501-7bf5e7010e39" : {
      "Path_3" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_4" : [
        "d11a9252-a8fb-4d39-8501-7bf5e7010e39"
      ],
      "Path_6" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Rectangle_4" : [
        "449ef3fa-cb12-499c-850b-9d235faaa5da"
      ],
      "Text_21" : [
        "449ef3fa-cb12-499c-850b-9d235faaa5da"
      ],
      "Text_1" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Text_3" : [
        "449ef3fa-cb12-499c-850b-9d235faaa5da"
      ],
      "Text_8" : [
        "449ef3fa-cb12-499c-850b-9d235faaa5da"
      ],
      "Rectangle_3" : [
        "4ffd4d39-045b-4131-a48d-1fe27d8bd287"
      ]
    },
    "667faad0-092e-47b1-a674-178de97be8c5" : {
      "Rectangle_6" : [
        "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"
      ],
      "Path_4" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_5" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_7" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Path_8" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Button_2" : [
        "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"
      ],
      "Image_8" : [
        "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"
      ],
      "Text_9" : [
        "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"
      ],
      "Text_14" : [
        "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"
      ],
      "Path_17" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ],
      "Path_18" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ],
      "Path_19" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ],
      "Path_20" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ],
      "Path_21" : [
        "1189be83-d238-44ef-8484-e2741b9b1679"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_1" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Hotspot_2" : [
        "32231785-f960-4fea-9baf-00b50be60690"
      ]
    },
    "611cb570-4f7a-4d41-999c-3a379908ef12" : {
      "Path_3" : [
        "4fd198ed-59ae-4a63-9437-39f7e5c081b1"
      ],
      "Path_4" : [
        "611cb570-4f7a-4d41-999c-3a379908ef12"
      ],
      "Path_6" : [
        "1b6cf767-c424-42c6-abc7-a45fd636baa9"
      ],
      "Rectangle_4" : [
        "fbf73125-c0bb-4e96-b775-5131ea7dda66"
      ],
      "Text_21" : [
        "fbf73125-c0bb-4e96-b775-5131ea7dda66"
      ],
      "Path_10" : [
        "fbf73125-c0bb-4e96-b775-5131ea7dda66"
      ],
      "Text_24" : [
        "fbf73125-c0bb-4e96-b775-5131ea7dda66"
      ],
      "Text_25" : [
        "fbf73125-c0bb-4e96-b775-5131ea7dda66"
      ],
      "Image_9" : [
        "fbf73125-c0bb-4e96-b775-5131ea7dda66"
      ],
      "Text_2" : [
        "d11a9252-a8fb-4d39-8501-7bf5e7010e39"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);