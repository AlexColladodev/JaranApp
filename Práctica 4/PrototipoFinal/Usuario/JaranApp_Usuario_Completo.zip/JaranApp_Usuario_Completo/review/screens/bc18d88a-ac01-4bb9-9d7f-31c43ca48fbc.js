var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Seguidores y Seguidos"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Path_3" class="path firer ie-background commentable non-processed" customid="Line 2"   datasizewidth="388.87px" datasizeheight="3.00px" dataX="-13.93" dataY="138.90"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="387.86921420328565" height="2.0" viewBox="-13.934607101643142 138.89987213674937 387.86921420328565 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-bc18d" d="M-13.434607101643142 139.39987213674937 L373.4346071016425 140.14861541794835 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-bc18d" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer commentable non-processed" customid="Account_circle"   datasizewidth="46.00px" datasizeheight="46.00px" dataX="17.21" dataY="169.32"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="45.99999999999963" height="45.99999999999966" viewBox="17.20865124417577 169.32095344260551 45.99999999999963 45.99999999999966" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-bc18d" d="M40.208651244175584 169.32095344260551 C27.512651288044705 169.32095344260551 17.20865124417577 179.62495348647445 17.20865124417577 192.32095344260534 C17.20865124417577 205.01695339873623 27.512651288044705 215.32095344260517 40.208651244175584 215.32095344260517 C52.90465120030646 215.32095344260517 63.2086512441754 205.01695339873623 63.2086512441754 192.32095344260534 C63.2086512441754 179.62495348647445 52.90465229703192 169.32095344260551 40.208651244175584 169.32095344260551 Z M40.208651244175584 176.22095344260546 C44.02665116740477 176.22095344260546 47.10865124417553 179.30295351937622 47.10865124417553 183.1209534426054 C47.10865124417553 186.9389533658346 44.02665116740477 190.02095344260536 40.208651244175584 190.02095344260536 C36.390651320946404 190.02095344260536 33.30865124417564 186.9389533658346 33.30865124417564 183.1209534426054 C33.30865124417564 179.30295351937622 36.390651320946404 176.22095344260546 40.208651244175584 176.22095344260546 Z M40.208651244175584 208.88095300391504 C34.45865124417563 208.88095300391504 29.375651156437634 205.93695306971858 26.408651244175697 201.47495293811156 C26.477651242633424 196.89795291617708 35.60865124417562 194.3909531135877 40.208651244175584 194.3909531135877 C44.785651266110065 194.3909531135877 53.93965076161627 196.89795319035846 54.008651244175475 201.47495293811156 C51.041651331913535 205.93695306971858 45.95865124417554 208.88095300391504 40.208651244175584 208.88095300391504 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-bc18d" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_9" class="path firer click commentable non-processed" customid="Clear"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="298.92" dataY="181.32"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="298.9175213675207 181.32095344260534 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_9-bc18d" d="M320.9175213675207 183.53666748853865 L318.70180732158735 181.32095344260534 L309.9175213675207 190.10523939667203 L301.13323541345403 181.32095344260534 L298.9175213675207 183.53666748853865 L307.70180732158735 192.32095344260534 L298.9175213675207 201.10523939667203 L301.13323541345403 203.32095344260534 L309.9175213675207 194.53666748853865 L318.70180732158735 203.32095344260534 L320.9175213675207 201.10523939667203 L312.13323541345403 192.32095344260534 L320.9175213675207 183.53666748853865 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-bc18d" fill="#666666" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_8" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle 8"   datasizewidth="236.21px" datasizeheight="80.00px" datasizewidthpx="236.20887012334498" datasizeheightpx="80.00000000000023" dataX="61.90" dataY="366.60" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable hidden non-processed" customid="&iquest;Eliminar amigo?"   datasizewidth="124.48px" datasizeheight="18.00px" dataX="116.94" dataY="379.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">&iquest;Eliminar amigo</span><span id="rtr-s-Text_2_1">?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_10" class="rectangle manualfit firer click commentable hidden non-processed" customid="Rectangle 10"   datasizewidth="72.40px" datasizeheight="24.00px" datasizewidthpx="72.4030249891785" datasizeheightpx="24.0" dataX="93.30" dataY="414.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_10_0">No</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_11" class="rectangle manualfit firer click commentable hidden non-processed" customid="Rectangle 10"   datasizewidth="72.40px" datasizeheight="24.00px" datasizewidthpx="72.4030249891785" datasizeheightpx="24.0" dataX="200.11" dataY="414.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_11_0">S&iacute;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_12" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_12_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-bc18d" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-bc18d" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_14" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_14-bc18d" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-bc18d" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_15" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_15-bc18d" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-bc18d" fill="#FFFFFF" fill-opacity="0.3"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_16" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_16-bc18d" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-bc18d" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">9:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_17" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="8.23" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="8.227257896035209 51.0 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_17-bc18d" d="M30.22725789603521 60.625 L13.493507791131034 60.625 L21.179758000939383 52.93874979019165 L19.22725789603521 51.0 L8.227257896035209 62.0 L19.22725789603521 73.0 L21.166007850139632 71.06125004589558 L13.493507791131034 63.375 L30.22725789603521 63.375 L30.22725789603521 60.625 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-bc18d" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="Edwin_Yueng_Weng"   datasizewidth="163.08px" datasizeheight="20.00px" dataX="37.87" dataY="52.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Edwin_Yueng_Weng</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext autofit firer ie-background commentable non-processed" customid="Seguidores"   datasizewidth="126.33px" datasizeheight="29.00px" dataX="30.23" dataY="91.73" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Seguidores</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="Seguidos"   datasizewidth="102.80px" datasizeheight="29.00px" dataX="221.11" dataY="94.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">Seguidos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="136.43px" datasizeheight="7.00px" dataX="26.59" dataY="121.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="133.4251179245509" height="4.0" viewBox="26.58549219666255 121.49999999999999 133.4251179245509 4.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-bc18d" d="M28.08549219666255 122.99999999999999 L158.51061012121346 123.0 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-bc18d" fill="none" stroke-width="3.0" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="17.71" dataY="169.82" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Text_6" class="richtext autofit firer ie-background commentable non-processed" customid="Luis_Kp"   datasizewidth="61.25px" datasizeheight="20.00px" dataX="73.74" dataY="182.32" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">Luis_Kp</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer commentable non-processed" customid="Account_circle"   datasizewidth="46.00px" datasizeheight="46.00px" dataX="17.21" dataY="233.32"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="45.99999999999963" height="45.99999999999966" viewBox="17.20865124417577 233.32095344260551 45.99999999999963 45.99999999999966" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-bc18d" d="M40.208651244175584 233.32095344260551 C27.512651288044705 233.32095344260551 17.20865124417577 243.62495348647445 17.20865124417577 256.32095344260534 C17.20865124417577 269.01695339873623 27.512651288044705 279.3209534426052 40.208651244175584 279.3209534426052 C52.90465120030646 279.3209534426052 63.2086512441754 269.01695339873623 63.2086512441754 256.32095344260534 C63.2086512441754 243.62495348647445 52.90465229703192 233.32095344260551 40.208651244175584 233.32095344260551 Z M40.208651244175584 240.22095344260546 C44.02665116740477 240.22095344260546 47.10865124417553 243.30295351937622 47.10865124417553 247.1209534426054 C47.10865124417553 250.9389533658346 44.02665116740477 254.02095344260536 40.208651244175584 254.02095344260536 C36.390651320946404 254.02095344260536 33.30865124417564 250.9389533658346 33.30865124417564 247.1209534426054 C33.30865124417564 243.30295351937622 36.390651320946404 240.22095344260546 40.208651244175584 240.22095344260546 Z M40.208651244175584 272.880953003915 C34.45865124417563 272.880953003915 29.375651156437634 269.9369530697186 26.408651244175697 265.4749529381116 C26.477651242633424 260.8979529161771 35.60865124417562 258.39095311358767 40.208651244175584 258.39095311358767 C44.785651266110065 258.39095311358767 53.93965076161627 260.89795319035846 54.008651244175475 265.4749529381116 C51.041651331913535 269.9369530697186 45.95865124417554 272.880953003915 40.208651244175584 272.880953003915 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-bc18d" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer click commentable non-processed" customid="Clear"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="298.92" dataY="245.32"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="298.9175213675207 245.32095344260534 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-bc18d" d="M320.9175213675207 247.53666748853865 L318.70180732158735 245.32095344260534 L309.9175213675207 254.10523939667203 L301.13323541345403 245.32095344260534 L298.9175213675207 247.53666748853865 L307.70180732158735 256.32095344260534 L298.9175213675207 265.105239396672 L301.13323541345403 267.32095344260534 L309.9175213675207 258.5366674885387 L318.70180732158735 267.32095344260534 L320.9175213675207 265.105239396672 L312.13323541345403 256.32095344260534 L320.9175213675207 247.53666748853865 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-bc18d" fill="#666666" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_2" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="45.00px" datasizeheight="45.00px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="17.71" dataY="233.82" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_2)">\
                          <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                          <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_2" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_2_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Text_7" class="richtext autofit firer ie-background commentable non-processed" customid="Miguel_h1"   datasizewidth="84.28px" datasizeheight="20.00px" dataX="73.74" dataY="246.32" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Miguel_h1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer click commentable non-processed" customid="Home"   datasizewidth="25.58px" datasizeheight="24.65px" dataX="30.35" dataY="735.17"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.58119658119638" height="24.649999999999864" viewBox="30.350000000000374 735.1749999999998 25.58119658119638 24.649999999999864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-bc18d" d="M40.582478632478924 759.8249999999997 L40.582478632478924 751.1249999999998 L45.698717948718205 751.1249999999998 L45.698717948718205 759.8249999999997 L52.094017094017296 759.8249999999997 L52.094017094017296 748.2249999999998 L55.93119658119676 748.2249999999998 L43.14059829059857 735.1749999999998 L30.350000000000374 748.2249999999998 L34.18717948717983 748.2249999999998 L34.18717948717983 759.8249999999997 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-bc18d" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer click commentable non-processed" customid="Event"   datasizewidth="23.02px" datasizeheight="29.00px" dataX="217.09" dataY="733.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.02307692307693" height="29.0" viewBox="217.09273504273483 732.9999999999999 23.02307692307693 29.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-bc18d" d="M234.99957264957246 748.9499999999999 L228.6042735042733 748.9499999999999 L228.6042735042733 756.1999999999999 L234.99957264957246 756.1999999999999 L234.99957264957246 748.9499999999999 Z M233.72051282051262 732.9999999999999 L233.72051282051262 735.8999999999999 L223.48803418803396 735.8999999999999 L223.48803418803396 732.9999999999999 L220.92991452991433 732.9999999999999 L220.92991452991433 735.8999999999999 L219.6508547008545 735.8999999999999 C218.23109827230098 735.8999999999999 217.10552562882737 737.2049999654292 217.10552562882737 738.7999999999998 L217.09273504273483 759.0999999999999 C217.09273504273483 760.6950000345706 218.23109827230098 761.9999999999999 219.6508547008545 761.9999999999999 L237.5576923076921 761.9999999999999 C238.96465815015307 761.9999999999999 240.11581196581176 760.6950000345706 240.11581196581176 759.0999999999999 L240.11581196581176 738.7999999999998 C240.11581196581176 737.2049999654292 238.96465815015307 735.8999999999999 237.5576923076921 735.8999999999999 L236.27863247863226 735.8999999999999 L236.27863247863226 732.9999999999999 L233.72051282051262 732.9999999999999 Z M237.5576923076921 759.0999999999999 L219.6508547008545 759.0999999999999 L219.6508547008545 743.1499999999999 L237.5576923076921 743.1499999999999 L237.5576923076921 759.0999999999999 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-bc18d" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_10" class="path firer commentable non-processed" customid="Search"   datasizewidth="22.37px" datasizeheight="25.36px" dataX="125.00" dataY="734.82"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.370756117502907" height="25.360499624907906" viewBox="125.00042735042783 734.8197501875461 22.370756117502907 25.360499624907906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_10-bc18d" d="M140.98867521367572 750.769750187546 L139.97821792127283 750.769750187546 L139.62008116761132 750.3782501719893 C140.87355963389132 748.7252504087985 141.62820512820565 746.579249689728 141.62820512820565 744.2447501875461 C141.62820512820565 739.0392499662937 137.90614122081058 734.8197501875461 133.31431623931672 734.8197501875461 C128.7224912578229 734.8197501875461 125.00042735042783 739.0392499662937 125.00042735042783 744.2447501875461 C125.00042735042783 749.4502504087985 128.7224912578229 753.669750187546 133.31431623931672 753.669750187546 C135.37360258240017 753.669750187546 137.26661100132904 752.8142502255738 138.72473934063595 751.3932501114905 L139.07008550820493 751.799250113219 L139.07008550820493 752.9447501443327 L145.4653846535041 760.180249812454 L147.37118346793073 758.019750187546 L140.98867521367572 750.769750187546 Z M133.31431623931672 750.769750187546 C130.1294575577113 750.769750187546 127.55854700854749 747.8552498556674 127.55854700854749 744.2447501875461 C127.55854700854749 740.6342505194248 130.1294575577113 737.7197501875461 133.31431623931672 737.7197501875461 C136.49917492092214 737.7197501875461 139.07008547008598 740.6342505194248 139.07008547008598 744.2447501875461 C139.07008547008598 747.8552498556674 136.49917492092214 750.769750187546 133.31431623931672 750.769750187546 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-bc18d" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_11" class="path firer click commentable non-processed" customid="User"   datasizewidth="20.46px" datasizeheight="23.20px" dataX="309.19" dataY="735.90"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.46495726495732" height="23.199999999999704" viewBox="309.1850427350427 735.9000000000005 20.46495726495732 23.199999999999704" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_11-bc18d" d="M319.4175213675214 747.5000000000005 C322.24424363853586 747.5000000000005 324.5337606837607 744.9045000553135 324.5337606837607 741.7000000000005 C324.5337606837607 738.4954999446874 322.24424363853586 735.9000000000005 319.4175213675214 735.9000000000005 C316.5907990965069 735.9000000000005 314.30128205128204 738.4954999446874 314.30128205128204 741.7000000000005 C314.30128205128204 744.9045000553135 316.5907990965069 747.5000000000005 319.4175213675214 747.5000000000005 Z M319.4175213675214 750.4000000000003 C316.0024315263471 750.4000000000003 309.1850427350427 752.3430000483993 309.1850427350427 756.2000000000003 L309.1850427350427 759.1000000000003 L329.65000000000003 759.1000000000003 L329.65000000000003 756.2000000000003 C329.65000000000003 752.3429998755458 322.83261120869565 750.4000000000003 319.4175213675214 750.4000000000003 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-bc18d" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_382" class="path firer commentable non-processed" customid="Add User"   datasizewidth="29.42px" datasizeheight="22.00px" dataX="319.50" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.417521367520635" height="22.0" viewBox="319.4999999999997 51.000000000000114 29.417521367520635 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_382-bc18d" d="M338.2202408702401 62.000000000000114 C341.1753646586224 62.000000000000114 343.56888111888026 59.5387500524522 343.56888111888026 56.500000000000114 C343.56888111888026 53.461249947548026 341.1753646586224 51.000000000000114 338.2202408702401 51.000000000000114 C335.26511708185785 51.000000000000114 332.8716006216 53.461249947548026 332.8716006216 56.500000000000114 C332.8716006216 59.5387500524522 335.26511708185785 62.000000000000114 338.2202408702401 62.000000000000114 Z M338.2202408702401 53.750000000000114 C339.6911169704965 53.750000000000114 340.89456099456015 54.98749996721756 340.89456099456015 56.500000000000114 C340.89456099456015 58.01250003278267 339.6911169704965 59.250000000000114 338.2202408702401 59.250000000000114 C336.7493647699837 59.250000000000114 335.54592074592006 58.01250003278267 335.54592074592006 56.500000000000114 C335.54592074592006 54.98749996721756 336.7493647699837 53.750000000000114 338.2202408702401 53.750000000000114 Z M338.2202408702401 64.75000000000011 C334.6500234022556 64.75000000000011 327.5229603729599 66.59250004589569 327.5229603729599 70.25000000000011 L327.5229603729599 73.00000000000011 L348.91752136752035 73.00000000000011 L348.91752136752035 70.25000000000011 C348.91752136752035 66.59249988198292 341.7904583382246 64.75000000000011 338.2202408702401 64.75000000000011 Z M330.19728049727996 70.25000000000011 C330.49145570936116 69.25999996066105 334.6232802265167 67.50000000000011 338.2202408702401 67.50000000000011 C341.83057310183295 67.50000000000011 345.9757694858113 69.27374994754803 346.2432012432003 70.25000000000011 L330.19728049727996 70.25000000000011 Z M326.18580031079983 66.12500000000011 L326.18580031079983 62.000000000000114 L330.19728049727996 62.000000000000114 L330.19728049727996 59.250000000000114 L326.18580031079983 59.250000000000114 L326.18580031079983 55.125000000000114 L323.5114801864798 55.125000000000114 L323.5114801864798 59.250000000000114 L319.4999999999997 59.250000000000114 L319.4999999999997 62.000000000000114 L323.5114801864798 62.000000000000114 L323.5114801864798 66.12500000000011 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_382-bc18d" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;