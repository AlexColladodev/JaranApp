var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="LogIn"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/d12245cc-1680-458d-89dd-4f0d7fb22724/style-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="LogoJaranApp"   datasizewidth="227.00px" datasizeheight="209.99px" dataX="66.00" dataY="97.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e44e9c80-1345-4963-b736-451fe90a76a6.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="LOGINGOOGLE"   datasizewidth="222.00px" datasizeheight="52.04px" dataX="69.00" dataY="362.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d8a0a646-3cc8-4bd4-b328-662ac084231c.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="LOGINFACEBOOK"   datasizewidth="222.00px" datasizeheight="52.04px" dataX="69.00" dataY="427.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/50408a45-fb11-49bd-895d-86c351641db8.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_text_1" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="30.00" dataY="519.05" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Email or Username"/></div></div>  </div></div></div>\
      <div id="s-Path_143" class="path firer commentable non-processed" customid="Email outline"   datasizewidth="20.00px" datasizeheight="16.00px" dataX="43.00" dataY="534.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="16.0" viewBox="42.9999999999996 534.0 20.0 16.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_143-d1224" d="M60.9999999999996 534.0 L44.9999999999996 534.0 C43.899999976157744 534.0 43.00999999046286 534.8999999761581 43.00999999046286 536.0 L42.9999999999996 548.0 C42.9999999999996 549.1000000238419 43.899999976157744 550.0 44.9999999999996 550.0 L60.9999999999996 550.0 C62.10000002384146 550.0 62.9999999999996 549.1000000238419 62.9999999999996 548.0 L62.9999999999996 536.0 C62.9999999999996 534.8999999761581 62.10000002384146 534.0 60.9999999999996 534.0 Z M60.9999999999996 548.0 L44.9999999999996 548.0 L44.9999999999996 538.0 L52.9999999999996 543.0 L60.9999999999996 538.0 L60.9999999999996 548.0 Z M52.9999999999996 541.0 L44.9999999999996 536.0 L60.9999999999996 536.0 L52.9999999999996 541.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_143-d1224" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_text_2" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="30.00" dataY="579.05" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Password"/></div></div>  </div></div></div>\
      <div id="s-Path_239" class="path firer commentable non-processed" customid="Lock Outline"   datasizewidth="16.00px" datasizeheight="21.00px" dataX="45.00" dataY="591.05"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="21.0" viewBox="44.99999999999973 591.0456564299863 16.0 21.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_239-d1224" d="M58.99999999999973 598.0456564299863 L57.99999999999973 598.0456564299863 L57.99999999999973 596.0456564299863 C57.99999999999973 593.285656439523 55.75999999046299 591.0456564299863 52.99999999999973 591.0456564299863 C50.24000000953647 591.0456564299863 47.99999999999973 593.285656439523 47.99999999999973 596.0456564299863 L47.99999999999973 598.0456564299863 L46.99999999999973 598.0456564299863 C45.89999997615787 598.0456564299863 44.99999999999973 598.9456564061444 44.99999999999973 600.0456564299863 L44.99999999999973 610.0456564299863 C44.99999999999973 611.1456564538281 45.89999997615787 612.0456564299863 46.99999999999973 612.0456564299863 L58.99999999999973 612.0456564299863 C60.10000002384159 612.0456564299863 60.99999999999973 611.1456564538281 60.99999999999973 610.0456564299863 L60.99999999999973 600.0456564299863 C60.99999999999973 598.9456564061444 60.10000002384159 598.0456564299863 58.99999999999973 598.0456564299863 Z M49.99999999999973 596.0456564299863 C49.99999999999973 594.3856564633649 51.34000003337833 593.0456564299863 52.99999999999973 593.0456564299863 C54.65999996662113 593.0456564299863 55.99999999999973 594.3856564633649 55.99999999999973 596.0456564299863 L55.99999999999973 598.0456564299863 L49.99999999999973 598.0456564299863 L49.99999999999973 596.0456564299863 Z M58.99999999999973 610.0456564299863 L46.99999999999973 610.0456564299863 L46.99999999999973 600.0456564299863 L58.99999999999973 600.0456564299863 L58.99999999999973 610.0456564299863 Z M52.99999999999973 607.0456564299863 C54.10000002384159 607.0456564299863 54.99999999999973 606.1456564538281 54.99999999999973 605.0456564299863 C54.99999999999973 603.9456564061444 54.10000002384159 603.0456564299863 52.99999999999973 603.0456564299863 C51.89999997615787 603.0456564299863 50.99999999999973 603.9456564061444 50.99999999999973 605.0456564299863 C50.99999999999973 606.1456564538281 51.89999997615787 607.0456564299863 52.99999999999973 607.0456564299863 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_239-d1224" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="&iquest;Olvidaste tu contrase&ntilde;a?"   datasizewidth="186.77px" datasizeheight="18.00px" dataX="143.23" dataY="635.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">&iquest;Olvidaste tu contrase&ntilde;a?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="No tienes una cuenta?"   datasizewidth="160.12px" datasizeheight="18.00px" dataX="45.00" dataY="755.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">No tienes una cuenta?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="Crear cuenta"   datasizewidth="92.49px" datasizeheight="18.00px" dataX="211.00" dataY="755.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Crear cuenta</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Iniciar Sesi&oacute;n"   datasizewidth="274.33px" datasizeheight="29.00px" dataX="42.83" dataY="667.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Iniciar Sesi&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="274.33px" datasizeheight="29.00px" dataX="42.83" dataY="667.00"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="100.00px" datasizeheight="18.00px" dataX="207.25" dataY="755.00"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;