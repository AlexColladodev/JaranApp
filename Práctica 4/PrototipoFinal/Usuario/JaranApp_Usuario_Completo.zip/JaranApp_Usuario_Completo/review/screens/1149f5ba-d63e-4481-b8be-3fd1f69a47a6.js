var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-1149f5ba-d63e-4481-b8be-3fd1f69a47a6" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Detalle Evento"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/1149f5ba-d63e-4481-b8be-3fd1f69a47a6/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/1149f5ba-d63e-4481-b8be-3fd1f69a47a6/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Halloween Party"   datasizewidth="202.09px" datasizeheight="58.00px" dataX="15.00" dataY="276.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Halloween Party</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="&iexcl;Vive una noche aterrador"   datasizewidth="327.50px" datasizeheight="102.00px" dataX="16.25" dataY="331.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">&iexcl;Vive una noche aterradora llena de m&uacute;sica, luces y diversi&oacute;n! Disfruta de una fiesta tem&aacute;tica con ambiente espeluznante, DJ en vivo y sorpresas para una experiencia inolvidable.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="20"   datasizewidth="27.82px" datasizeheight="29.00px" dataX="270.18" dataY="276.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">20</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_22" class="path firer commentable non-processed" customid="Euro"   datasizewidth="19.00px" datasizeheight="18.00px" dataX="303.50" dataY="281.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.999999999999996" height="18.0" viewBox="303.49999999999983 281.49999999999994 18.999999999999996 18.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_22-1149f" d="M316.49999999999983 296.99999999999994 C313.9900000095366 296.99999999999994 311.8200001716612 295.5800000429153 310.739999771118 293.49999999999994 L316.49999999999983 293.49999999999994 L317.49999999999983 291.49999999999994 L310.0799999237059 291.49999999999994 C310.0299999229608 291.1699999868869 309.999999925494 290.8399999737739 309.999999925494 290.49999999999994 C309.999999925494 290.160000026226 310.02999992482347 289.82999998331064 310.0799999237059 289.49999999999994 L316.49999999999983 289.49999999999994 L317.49999999999983 287.49999999999994 L310.739999771118 287.49999999999994 C311.81999969482405 285.4200000762939 313.99999999999983 283.99999999999994 316.49999999999983 283.99999999999994 C318.11000001430494 283.99999999999994 319.58999991416914 284.5899999737739 320.7300000190733 285.57000005245203 L322.49999999999983 283.8000001907348 C320.90999984741194 282.369999885559 318.7999992370604 281.49999999999994 316.49999999999983 281.49999999999994 C312.5799999237059 281.49999999999994 309.26000022888167 284.0099999904632 308.0200004577635 287.49999999999994 L304.49999999999983 287.49999999999994 L303.49999999999983 289.49999999999994 L307.55999994277937 289.49999999999994 C307.51999998092634 289.829999923706 307.49999999999983 290.15999984741205 307.49999999999983 290.49999999999994 C307.49999999999983 290.84000015258783 307.5199999995528 291.17000001668924 307.5599999986587 291.49999999999994 L304.49999999999983 291.49999999999994 L303.49999999999983 293.49999999999994 L308.01999998092634 293.49999999999994 C309.2599999904631 296.9900000095367 312.5799999237059 299.49999999999994 316.49999952316267 299.49999999999994 C318.8099994659422 299.49999999999994 320.9099993705748 298.62999999523157 322.49999952316267 297.20000004768366 L320.7199995517729 295.43000006675715 C319.5900001525877 296.40999984741205 318.1200008392332 296.99999999999994 316.49999999999983 296.99999999999994 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_22-1149f" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer click commentable non-processed" customid="Home"   datasizewidth="25.58px" datasizeheight="24.65px" dataX="30.35" dataY="740.68"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.58119658119638" height="24.649999999999864" viewBox="30.350000000000463 740.675 25.58119658119638 24.649999999999864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-1149f" d="M40.58247863247902 765.3249999999998 L40.58247863247902 756.6249999999999 L45.6987179487183 756.6249999999999 L45.6987179487183 765.3249999999998 L52.09401709401739 765.3249999999998 L52.09401709401739 753.7249999999999 L55.93119658119684 753.7249999999999 L43.14059829059865 740.675 L30.350000000000463 753.7249999999999 L34.18717948717992 753.7249999999999 L34.18717948717992 765.3249999999998 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-1149f" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer click commentable non-processed" customid="Event"   datasizewidth="23.02px" datasizeheight="29.00px" dataX="217.09" dataY="738.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.02307692307693" height="29.0" viewBox="217.09273504273492 738.5 23.02307692307693 29.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-1149f" d="M234.99957264957254 754.45 L228.60427350427338 754.45 L228.60427350427338 761.7 L234.99957264957254 761.7 L234.99957264957254 754.45 Z M233.7205128205127 738.5 L233.7205128205127 741.4 L223.48803418803405 741.4 L223.48803418803405 738.5 L220.9299145299144 738.5 L220.9299145299144 741.4 L219.65085470085458 741.4 C218.23109827230107 741.4 217.10552562882745 742.7049999654294 217.10552562882745 744.3 L217.09273504273492 764.6 C217.09273504273492 766.1950000345707 218.23109827230107 767.5 219.65085470085458 767.5 L237.55769230769218 767.5 C238.96465815015316 767.5 240.11581196581184 766.1950000345707 240.11581196581184 764.6 L240.11581196581184 744.3 C240.11581196581184 742.7049999654294 238.96465815015316 741.4 237.55769230769218 741.4 L236.27863247863235 741.4 L236.27863247863235 738.5 L233.7205128205127 738.5 Z M237.55769230769218 764.6 L219.65085470085458 764.6 L219.65085470085458 748.65 L237.55769230769218 748.65 L237.55769230769218 764.6 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-1149f" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer commentable non-processed" customid="Search"   datasizewidth="22.37px" datasizeheight="25.36px" dataX="125.00" dataY="740.32"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.370756117502907" height="25.360499624907906" viewBox="125.00042735042793 740.3197501875462 22.370756117502907 25.360499624907906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-1149f" d="M140.98867521367583 756.2697501875462 L139.97821792127291 756.2697501875462 L139.6200811676114 755.8782501719894 C140.8735596338914 754.2252504087986 141.62820512820574 752.0792496897282 141.62820512820574 749.7447501875462 C141.62820512820574 744.5392499662937 137.90614122081067 740.3197501875462 133.31431623931684 740.3197501875462 C128.722491257823 740.3197501875462 125.00042735042793 744.5392499662937 125.00042735042793 749.7447501875462 C125.00042735042793 754.9502504087986 128.722491257823 759.1697501875461 133.31431623931684 759.1697501875461 C135.37360258240025 759.1697501875461 137.26661100132912 758.3142502255739 138.72473934063606 756.8932501114906 L139.07008550820504 757.2992501132192 L139.07008550820504 758.4447501443328 L145.4653846535042 765.6802498124541 L147.37118346793085 763.5197501875462 L140.98867521367583 756.2697501875462 Z M133.31431623931684 756.2697501875462 C130.12945755771142 756.2697501875462 127.55854700854759 753.3552498556676 127.55854700854759 749.7447501875462 C127.55854700854759 746.1342505194249 130.12945755771142 743.2197501875462 133.31431623931684 743.2197501875462 C136.49917492092226 743.2197501875462 139.07008547008607 746.1342505194249 139.07008547008607 749.7447501875462 C139.07008547008607 753.3552498556676 136.49917492092226 756.2697501875462 133.31431623931684 756.2697501875462 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-1149f" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer click commentable non-processed" customid="User"   datasizewidth="20.46px" datasizeheight="23.20px" dataX="309.19" dataY="741.40"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.46495726495732" height="23.199999999999704" viewBox="309.18504273504277 741.4000000000007 20.46495726495732 23.199999999999704" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-1149f" d="M319.41752136752143 753.0000000000005 C322.2442436385359 753.0000000000005 324.53376068376076 750.4045000553136 324.53376068376076 747.2000000000006 C324.53376068376076 743.9954999446875 322.2442436385359 741.4000000000007 319.41752136752143 741.4000000000007 C316.59079909650694 741.4000000000007 314.3012820512821 743.9954999446875 314.3012820512821 747.2000000000006 C314.3012820512821 750.4045000553136 316.59079909650694 753.0000000000005 319.41752136752143 753.0000000000005 Z M319.41752136752143 755.9000000000004 C316.00243152634715 755.9000000000004 309.18504273504277 757.8430000483994 309.18504273504277 761.7000000000004 L309.18504273504277 764.6000000000004 L329.6500000000001 764.6000000000004 L329.6500000000001 761.7000000000004 C329.6500000000001 757.842999875546 322.8326112086957 755.9000000000004 319.41752136752143 755.9000000000004 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-1149f" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-1149f" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-1149f" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-1149f" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-1149f" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_9" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_9-1149f" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-1149f" fill="#FFFFFF" fill-opacity="0.3"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_10" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_10-1149f" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-1149f" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_6" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">9:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="8.23" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="8.227257896035209 51.0 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-1149f" d="M30.22725789603521 60.625 L13.493507791131034 60.625 L21.179758000939383 52.93874979019165 L19.22725789603521 51.0 L8.227257896035209 62.0 L19.22725789603521 73.0 L21.166007850139632 71.06125004589558 L13.493507791131034 63.375 L30.22725789603521 63.375 L30.22725789603521 60.625 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-1149f" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Share"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="317.00" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="317.0 51.00000000000004 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-1149f" d="M335.3333333333333 66.55020089547844 C334.40444445610046 66.55020089547844 333.5733332633972 66.88152620659717 332.9377777311537 67.40060247249285 L324.22333314683704 62.81726907881679 C324.28444425885874 62.56325301244479 324.333333151208 62.309236946072794 324.333333151208 62.04417673009202 C324.333333151208 61.77911651411124 324.2844442634119 61.525100431282134 324.22333314683704 61.271084381367245 L332.8400000466241 56.731927651954734 C333.5000000728501 57.284136481876494 334.36777782440186 57.62650595906112 335.3333333333333 57.62650595906112 C337.36222218142615 57.62650595906112 339.0 56.14658625800689 339.0 54.31325297953058 C339.0 52.479919701054264 337.36222218142615 51.00000000000004 335.3333333333333 51.00000000000004 C333.30444448524054 51.00000000000004 331.6666666666667 52.479919701054264 331.6666666666667 54.31325297953058 C331.6666666666667 54.578313211968464 331.7155555544628 54.83232927834047 331.7766666710377 55.086345328255355 L323.1599999533759 59.62550271595208 C322.5 59.07329388603033 321.63222217559814 58.730923948046744 320.6666666666667 58.730923948046744 C318.63777781857385 58.730923948046744 317.0 60.210843649100966 317.0 62.04417692757728 C317.0 63.8775102060536 318.63777781857385 65.35742990710781 320.6666666666667 65.35742990710781 C321.6322222484483 65.35742990710781 322.5 65.0150604299232 323.1599999533759 64.46285160000144 L331.8622220357259 69.05722889642969 C331.8011109237042 69.2891565977557 331.76444426013364 69.53212849806181 331.76444426013364 69.7751003489966 C331.76444426013364 71.55321279714349 333.36555530130863 73.00000000000004 335.33333324227067 73.00000000000004 C337.3011110375325 73.00000000000004 338.90222222440775 71.55321292880032 338.90222222440775 69.7751003489966 C338.90222222440775 67.99698776919288 337.3011111832327 66.55020069799316 335.33333324227067 66.55020069799316 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-1149f" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Evento en Establecimiento"   datasizewidth="225.18px" datasizeheight="20.00px" dataX="37.87" dataY="52.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">Evento en Establecimiento 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Evento1"   datasizewidth="343.55px" datasizeheight="180.27px" dataX="8.23" dataY="87.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b1512709-a16a-48a1-894e-1d8e10e23e24.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Asistir"   datasizewidth="274.33px" datasizeheight="29.00px" dataX="42.83" dataY="671.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Asistir</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;