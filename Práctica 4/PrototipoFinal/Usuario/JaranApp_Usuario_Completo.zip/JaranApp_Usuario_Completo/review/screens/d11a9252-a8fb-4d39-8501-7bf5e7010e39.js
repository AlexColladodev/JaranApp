var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d11a9252-a8fb-4d39-8501-7bf5e7010e39" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="ActEvents-Actividades"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/d11a9252-a8fb-4d39-8501-7bf5e7010e39/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/d11a9252-a8fb-4d39-8501-7bf5e7010e39/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Path_3" class="path firer click commentable non-processed" customid="Home"   datasizewidth="25.58px" datasizeheight="24.65px" dataX="36.26" dataY="730.92"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.58119658119638" height="24.649999999999864" viewBox="36.25506339303118 730.9237563187232 25.58119658119638 24.649999999999864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-d11a9" d="M46.48754202550973 755.5737563187231 L46.48754202550973 746.8737563187232 L51.60378134174901 746.8737563187232 L51.60378134174901 755.5737563187231 L57.999080487048104 755.5737563187231 L57.999080487048104 743.9737563187232 L61.83625997422756 743.9737563187232 L49.04566168362937 730.9237563187232 L36.25506339303118 743.9737563187232 L40.092242880210634 743.9737563187232 L40.092242880210634 755.5737563187231 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-d11a9" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer click commentable non-processed" customid="Event"   datasizewidth="23.02px" datasizeheight="29.00px" dataX="223.00" dataY="728.75"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.02307692307693" height="29.0" viewBox="222.99779843576562 728.7487563187233 23.02307692307693 29.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-d11a9" d="M240.90463604260324 744.6987563187233 L234.50933689730408 744.6987563187233 L234.50933689730408 751.9487563187233 L240.90463604260324 751.9487563187233 L240.90463604260324 744.6987563187233 Z M239.6255762135434 728.7487563187233 L239.6255762135434 731.6487563187233 L229.39309758106475 731.6487563187233 L229.39309758106475 728.7487563187233 L226.83497792294511 728.7487563187233 L226.83497792294511 731.6487563187233 L225.55591809388528 731.6487563187233 C224.13616166533177 731.6487563187233 223.01058902185815 732.9537562841526 223.01058902185815 734.5487563187232 L222.99779843576562 754.8487563187233 C222.99779843576562 756.443756353294 224.13616166533177 757.7487563187233 225.55591809388528 757.7487563187233 L243.46275570072288 757.7487563187233 C244.86972154318386 757.7487563187233 246.02087535884255 756.443756353294 246.02087535884255 754.8487563187233 L246.02087535884255 734.5487563187232 C246.02087535884255 732.9537562841526 244.86972154318386 731.6487563187233 243.46275570072288 731.6487563187233 L242.18369587166305 731.6487563187233 L242.18369587166305 728.7487563187233 L239.6255762135434 728.7487563187233 Z M243.46275570072288 754.8487563187233 L225.55591809388528 754.8487563187233 L225.55591809388528 738.8987563187233 L243.46275570072288 738.8987563187233 L243.46275570072288 754.8487563187233 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-d11a9" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer commentable non-processed" customid="Search"   datasizewidth="22.37px" datasizeheight="25.36px" dataX="130.91" dataY="730.57"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.370756117502907" height="25.360499624907906" viewBox="130.90549074345864 730.5685065062695 22.370756117502907 25.360499624907906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-d11a9" d="M146.89373860670656 746.5185065062694 L145.88328131430364 746.5185065062694 L145.52514456064213 746.1270064907127 C146.7786230269221 744.4740067275219 147.53326852123647 742.3280060084514 147.53326852123647 739.9935065062695 C147.53326852123647 734.788006285017 143.8112046138414 730.5685065062695 139.21937963234757 730.5685065062695 C134.6275546508537 730.5685065062695 130.90549074345864 734.788006285017 130.90549074345864 739.9935065062695 C130.90549074345864 745.1990067275219 134.6275546508537 749.4185065062694 139.21937963234757 749.4185065062694 C141.27866597543098 749.4185065062694 143.17167439435985 748.5630065442972 144.62980273366676 747.1420064302139 L144.97514890123574 747.5480064319424 L144.97514890123574 748.6935064630561 L151.3704480465349 755.9290061311774 L153.27624686096155 753.7685065062694 L146.89373860670656 746.5185065062694 Z M139.21937963234757 746.5185065062694 C136.03452095074212 746.5185065062694 133.4636104015783 743.6040061743909 133.4636104015783 739.9935065062695 C133.4636104015783 736.3830068381482 136.03452095074212 733.4685065062695 139.21937963234757 733.4685065062695 C142.404238313953 733.4685065062695 144.9751488631168 736.3830068381482 144.9751488631168 739.9935065062695 C144.9751488631168 743.6040061743909 142.404238313953 746.5185065062694 139.21937963234757 746.5185065062694 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-d11a9" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer click commentable non-processed" customid="User"   datasizewidth="20.46px" datasizeheight="23.20px" dataX="315.09" dataY="731.65"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.46495726495732" height="23.199999999999704" viewBox="315.0901061280735 731.6487563187239 20.46495726495732 23.199999999999704" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-d11a9" d="M325.32258476055216 743.2487563187237 C328.14930703156665 743.2487563187237 330.4388240767915 740.6532563740369 330.4388240767915 737.4487563187239 C330.4388240767915 734.2442562634108 328.14930703156665 731.6487563187239 325.32258476055216 731.6487563187239 C322.49586248953767 731.6487563187239 320.20634544431283 734.2442562634108 320.20634544431283 737.4487563187239 C320.20634544431283 740.6532563740369 322.49586248953767 743.2487563187237 325.32258476055216 743.2487563187237 Z M325.32258476055216 746.1487563187237 C321.9074949193779 746.1487563187237 315.0901061280735 748.0917563671227 315.0901061280735 751.9487563187237 L315.0901061280735 754.8487563187236 L335.5550633930308 754.8487563187236 L335.5550633930308 751.9487563187237 C335.5550633930308 748.0917561942692 328.73767460172644 746.1487563187237 325.32258476055216 746.1487563187237 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-d11a9" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="17.09" dataY="126.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_21" class="richtext autofit firer click ie-background commentable non-processed" customid="Noche de Cine en casa de "   datasizewidth="230.37px" datasizeheight="18.00px" dataX="28.16" dataY="132.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_21_0">Noche de Cine en casa de Carlos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Status bar light" datasizewidth="360.00px" datasizeheight="34.00px" dataX="0.00" dataY="0.00" >\
        <div id="s-Panel_1" class="panel default firer commentable non-processed" customid="Panel"  datasizewidth="360.00px" datasizeheight="34.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_16" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_16_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_98" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_98-d11a9" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_98-d11a9" fill="#FFFFFF" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_104" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_104-d11a9" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_104-d11a9" fill="#FFFFFF" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
                  <div id="s-Path_16" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_16-d11a9" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-d11a9" fill="#FFFFFF" fill-opacity="0.3"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_17" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_17-d11a9" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-d11a9" fill="#FFFFFF" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Paragraph_49" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_49_0">9:30</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Line 2"   datasizewidth="375.89px" datasizeheight="3.00px" dataX="-0.50" dataY="88.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="374.8925182447488" height="2.0" viewBox="-0.4999999999999023 88.5 374.8925182447488 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-d11a9" d="M9.769962616701378E-14 89.0 L373.89251824474894 89.0 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-d11a9" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext autofit firer click ie-background commentable non-processed" customid="Eventos"   datasizewidth="89.73px" datasizeheight="29.00px" dataX="52.36" dataY="46.73" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Eventos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="Actividades"   datasizewidth="132.13px" datasizeheight="29.00px" dataX="191.91" dataY="46.73" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Actividades</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Line_1" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="143.51px" datasizeheight="7.00px" dataX="186.30" dataY="73.73"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="140.50630014840118" height="4.0" viewBox="186.30472961704828 73.73206644334276 140.50630014840118 4.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Line_1-d11a9" d="M187.80472961704828 75.23206644334276 L325.31102976544946 75.23206644334276 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_1-d11a9" fill="none" stroke-width="3.0" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext manualfit firer click ie-background commentable non-processed" customid="Este viernes plan tranqui"   datasizewidth="297.15px" datasizeheight="44.00px" dataX="28.16" dataY="155.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Este viernes plan tranqui en casa de Carlos: peli, palomitas y sofazo. Caed sobre las 8 y traed algo para picar. Eso s&iacute;, nada de pelis raras, que os conozco.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="17.09" dataY="225.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext autofit firer ie-background commentable non-processed" customid="Partido de Furbo"   datasizewidth="117.92px" datasizeheight="18.00px" dataX="28.16" dataY="231.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Partido de Furbo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext manualfit firer ie-background commentable non-processed" customid="&iexcl;Chavales! El s&aacute;bado mont"   datasizewidth="307.39px" datasizeheight="44.00px" dataX="28.16" dataY="254.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">&iexcl;Chavales! El s&aacute;bado montamos pachanga en el parque de siempre. A las 5, no llegu&eacute;is tarde, que esta vez ganamos seguro. Y traed bal&oacute;n, que siempre andamos buscando uno.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="17.09" dataY="323.36" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_6" class="richtext autofit firer ie-background commentable non-processed" customid="Paseo a la Playa"   datasizewidth="114.90px" datasizeheight="18.00px" dataX="28.16" dataY="329.36" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">Paseo a la Playa</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Domingo de playita, gente"   datasizewidth="297.15px" datasizeheight="44.00px" dataX="28.16" dataY="352.36" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Domingo de playita, gente. Salimos a las 9, no os hag&aacute;is los remolones. Llevad crema, toalla y algo de papeo. Que ya toca un d&iacute;a guapo todos juntos.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_8" class="richtext manualfit firer click ie-background commentable non-processed" customid="31/01/2025 19:00"   datasizewidth="66.37px" datasizeheight="18.00px" dataX="269.18" dataY="199.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_8_0">31/01/2025 19:00</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_9" class="richtext manualfit firer ie-background commentable non-processed" customid="01/02/2025 16:30"   datasizewidth="66.37px" datasizeheight="18.00px" dataX="269.18" dataY="298.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_9_0">01/02/2025 16:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_10" class="richtext manualfit firer ie-background commentable non-processed" customid="01/02/2025 16:30"   datasizewidth="66.37px" datasizeheight="18.00px" dataX="269.18" dataY="298.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_10_0">01/02/2025 16:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_11" class="richtext manualfit firer ie-background commentable non-processed" customid="02/02/2025 08:30"   datasizewidth="66.37px" datasizeheight="18.00px" dataX="269.18" dataY="396.36" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_11_0">02/02/2025 08:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer click commentable non-processed" customid="BG"   datasizewidth="56.00px" datasizeheight="56.00px" datasizewidthpx="56.0" datasizeheightpx="56.0" dataX="279.56" dataY="642.72" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_191" class="path firer commentable non-processed" customid="Add"   datasizewidth="27.32px" datasizeheight="27.32px" dataX="293.89" dataY="657.06"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="27.322584760552104" height="27.32258476055199" viewBox="293.89377101275466 657.0571649286976 27.322584760552104 27.32258476055199" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_191-d11a9" d="M321.21635577330676 672.6700705061559 L309.506676590213 672.6700705061559 L309.506676590213 684.3797496892496 L305.60345019584844 684.3797496892496 L305.60345019584844 672.6700705061559 L293.89377101275466 672.6700705061559 L293.89377101275466 668.7668441117913 L305.60345019584844 668.7668441117913 L305.60345019584844 657.0571649286976 L309.506676590213 657.0571649286976 L309.506676590213 668.7668441117913 L321.21635577330676 668.7668441117913 L321.21635577330676 672.6700705061559 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_191-d11a9" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;