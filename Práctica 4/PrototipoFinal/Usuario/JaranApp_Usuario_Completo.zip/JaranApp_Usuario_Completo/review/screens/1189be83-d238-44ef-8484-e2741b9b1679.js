var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-1189be83-d238-44ef-8484-e2741b9b1679" class="screen growth-both devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Crear Rese&ntilde;a"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/1189be83-d238-44ef-8484-e2741b9b1679/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/1189be83-d238-44ef-8484-e2741b9b1679/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Publicar Rese&ntilde;a"   datasizewidth="274.33px" datasizeheight="29.00px" dataX="42.83" dataY="665.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Publicar Rese&ntilde;a</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-1189b" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-1189b" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-1189b" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-1189b" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_3" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-1189b" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-1189b" fill="#FFFFFF" fill-opacity="0.3"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_4" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_4-1189b" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-1189b" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_13" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_13_0">9:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer click commentable non-processed" customid="Clear"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="17.83" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="17.833965910774538 51.0 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-1189b" d="M39.83396591077454 53.21571404593331 L37.61825186484123 51.0 L28.833965910774538 59.78428595406669 L20.049679956707852 51.0 L17.833965910774538 53.21571404593331 L26.618251864841227 62.0 L17.833965910774538 70.78428595406669 L20.049679956707852 73.0 L28.833965910774538 64.21571404593331 L37.61825186484123 73.0 L39.83396591077454 70.78428595406669 L31.049679956707852 62.0 L39.83396591077454 53.21571404593331 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-1189b" fill="#434343" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer click commentable non-processed" customid="Home"   datasizewidth="25.58px" datasizeheight="24.65px" dataX="30.35" dataY="732.75"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.58119658119638" height="24.649999999999864" viewBox="30.350000000000072 732.7450000000001 25.58119658119638 24.649999999999864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-1189b" d="M40.582478632478626 757.395 L40.582478632478626 748.695 L45.6987179487179 748.695 L45.6987179487179 757.395 L52.09401709401699 757.395 L52.09401709401699 745.7950000000001 L55.93119658119645 745.7950000000001 L43.14059829059826 732.7450000000001 L30.350000000000072 745.7950000000001 L34.18717948717953 745.7950000000001 L34.18717948717953 757.395 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-1189b" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer click commentable non-processed" customid="Event"   datasizewidth="23.02px" datasizeheight="29.00px" dataX="217.09" dataY="730.57"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.02307692307693" height="29.0" viewBox="217.09273504273452 730.57 23.02307692307693 29.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-1189b" d="M234.99957264957214 746.5200000000001 L228.60427350427298 746.5200000000001 L228.60427350427298 753.7700000000001 L234.99957264957214 753.7700000000001 L234.99957264957214 746.5200000000001 Z M233.7205128205123 730.57 L233.7205128205123 733.47 L223.48803418803365 733.47 L223.48803418803365 730.57 L220.92991452991402 730.57 L220.92991452991402 733.47 L219.65085470085418 733.47 C218.23109827230067 733.47 217.10552562882705 734.7749999654294 217.10552562882705 736.37 L217.09273504273452 756.6700000000001 C217.09273504273452 758.2650000345708 218.23109827230067 759.57 219.65085470085418 759.57 L237.55769230769178 759.57 C238.96465815015276 759.57 240.11581196581145 758.2650000345708 240.11581196581145 756.6700000000001 L240.11581196581145 736.37 C240.11581196581145 734.7749999654294 238.96465815015276 733.47 237.55769230769178 733.47 L236.27863247863195 733.47 L236.27863247863195 730.57 L233.7205128205123 730.57 Z M237.55769230769178 756.6700000000001 L219.65085470085418 756.6700000000001 L219.65085470085418 740.72 L237.55769230769178 740.72 L237.55769230769178 756.6700000000001 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-1189b" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer commentable non-processed" customid="Search"   datasizewidth="22.37px" datasizeheight="25.36px" dataX="125.00" dataY="732.39"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.370756117502907" height="25.360499624907906" viewBox="125.00042735042753 732.389750187546 22.370756117502907 25.360499624907906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-1189b" d="M140.98867521367544 748.339750187546 L139.97821792127252 748.339750187546 L139.620081167611 747.9482501719892 C140.873559633891 746.2952504087984 141.62820512820534 744.149249689728 141.62820512820534 741.814750187546 C141.62820512820534 736.6092499662936 137.90614122081027 732.389750187546 133.31431623931644 732.389750187546 C128.7224912578226 732.389750187546 125.00042735042753 736.6092499662936 125.00042735042753 741.814750187546 C125.00042735042753 747.0202504087985 128.7224912578226 751.239750187546 133.31431623931644 751.239750187546 C135.37360258239985 751.239750187546 137.26661100132873 750.3842502255737 138.72473934063567 748.9632501114904 L139.07008550820464 749.369250113219 L139.07008550820464 750.5147501443327 L145.4653846535038 757.750249812454 L147.37118346793045 755.589750187546 L140.98867521367544 748.339750187546 Z M133.31431623931644 748.339750187546 C130.12945755771102 748.339750187546 127.5585470085472 745.4252498556673 127.5585470085472 741.814750187546 C127.5585470085472 738.2042505194247 130.12945755771102 735.289750187546 133.31431623931644 735.289750187546 C136.49917492092186 735.289750187546 139.07008547008567 738.2042505194247 139.07008547008567 741.814750187546 C139.07008547008567 745.4252498556673 136.49917492092186 748.339750187546 133.31431623931644 748.339750187546 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-1189b" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_9" class="path firer click commentable non-processed" customid="User"   datasizewidth="20.46px" datasizeheight="23.20px" dataX="309.19" dataY="733.47"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.46495726495732" height="23.199999999999704" viewBox="309.1850427350424 733.4700000000003 20.46495726495732 23.199999999999704" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_9-1189b" d="M319.41752136752103 745.0700000000002 C322.2442436385355 745.0700000000002 324.53376068376036 742.4745000553132 324.53376068376036 739.2700000000002 C324.53376068376036 736.0654999446871 322.2442436385355 733.4700000000003 319.41752136752103 733.4700000000003 C316.59079909650654 733.4700000000003 314.3012820512817 736.0654999446871 314.3012820512817 739.2700000000002 C314.3012820512817 742.4745000553132 316.59079909650654 745.0700000000002 319.41752136752103 745.0700000000002 Z M319.41752136752103 747.97 C316.00243152634675 747.97 309.1850427350424 749.913000048399 309.1850427350424 753.77 L309.1850427350424 756.67 L329.6499999999997 756.67 L329.6499999999997 753.77 C329.6499999999997 749.9129998755456 322.8326112086953 747.97 319.41752136752103 747.97 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-1189b" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_text_2" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="309.75px" datasizeheight="127.00px" dataX="25.12" dataY="157.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Rese&ntilde;a"/></div></div>  </div></div></div>\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Crear Rese&ntilde;a"   datasizewidth="225.18px" datasizeheight="20.00px" dataX="47.90" dataY="52.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Crear Rese&ntilde;a</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_10" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="88.00" dataY="101.69"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.26675243915518" height="29.266752439155088" viewBox="87.99704534667207 101.68698716746388 29.26675243915518 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_10-1189b" d="M117.26379778582725 112.83915984961413 L106.74240020021811 111.88413949951777 L102.63042156624965 101.68698716746388 L98.51844223450746 111.89954358961717 L87.99704534667207 112.83915984961413 L95.98686881838333 120.12504088095217 L93.58699531374926 130.95373960661897 L102.63042156624965 125.20821470131412 L111.67384851652382 130.95373960661897 L109.28860819971041 120.12504088095217 L117.26379778582725 112.83915984961413 Z M102.63042156624965 122.32774882642696 L97.12827212164396 125.82435553583026 L98.59160974360172 119.23163413688327 L93.73332893639028 114.79541043298428 L100.14274788803097 114.21007539154617 L102.63042156624965 108.0024441258555 L105.13272895561933 114.2254798488949 L111.54214790726002 114.81081489033302 L106.68386710004859 119.24703859423201 L108.14720472200634 125.839759993179 L102.63042156624965 122.32774882642696 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-1189b" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_11" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="126.68" dataY="101.69"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.266752439155184" height="29.266752439155088" viewBox="126.68183456354745 101.68698716746388 29.266752439155184 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_11-1189b" d="M155.94858700270265 112.83915984961413 L145.4271894170935 111.88413949951777 L141.31521078312505 101.68698716746388 L137.20323145138283 111.89954358961717 L126.68183456354745 112.83915984961413 L134.67165803525873 120.12504088095217 L132.27178453062464 130.95373960661897 L141.31521078312505 125.20821470131412 L150.3586377333992 130.95373960661897 L147.97339741658578 120.12504088095217 L155.94858700270265 112.83915984961413 Z M141.31521078312505 122.32774882642696 L135.81306133851933 125.82435553583026 L137.2763989604771 119.23163413688327 L132.41811815326568 114.79541043298428 L138.82753710490636 114.21007539154617 L141.31521078312505 108.0024441258555 L143.81751817249472 114.2254798488949 L150.2269371241354 114.81081489033302 L145.36865631692396 119.24703859423201 L146.83199393888174 125.839759993179 L141.31521078312505 122.32774882642696 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-1189b" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_13" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="165.37" dataY="101.69"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.2667524391551" height="29.266752439155088" viewBox="165.36662378042286 101.68698716746388 29.2667524391551 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_13-1189b" d="M194.63337621957794 112.83915984961413 L184.11197863396885 111.88413949951777 L180.0000000000004 101.68698716746388 L175.8880206682582 111.89954358961717 L165.36662378042286 112.83915984961413 L173.3564472521341 120.12504088095217 L170.95657374750002 130.95373960661897 L180.0000000000004 125.20821470131412 L189.04342695027452 130.95373960661897 L186.65818663346113 120.12504088095217 L194.63337621957794 112.83915984961413 Z M180.0000000000004 122.32774882642696 L174.4978505553947 125.82435553583026 L175.96118817735248 119.23163413688327 L171.10290737014105 114.79541043298428 L177.51232632178173 114.21007539154617 L180.0000000000004 108.0024441258555 L182.50230738937006 114.2254798488949 L188.91172634101073 114.81081489033302 L184.0534455337993 119.24703859423201 L185.51678315575705 125.839759993179 L180.0000000000004 122.32774882642696 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-1189b" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_14" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="204.05" dataY="101.69"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.266752439155056" height="29.266752439155088" viewBox="204.0514129972982 101.68698716746388 29.266752439155056 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_14-1189b" d="M233.31816543645326 112.83915984961413 L222.79676785084416 111.88413949951777 L218.68478921687574 101.68698716746388 L214.57280988513355 111.89954358961717 L204.0514129972982 112.83915984961413 L212.04123646900945 120.12504088095217 L209.64136296437536 130.95373960661897 L218.68478921687574 125.20821470131412 L227.72821616714984 130.95373960661897 L225.34297585033644 120.12504088095217 L233.31816543645326 112.83915984961413 Z M218.68478921687574 122.32774882642696 L213.18263977227005 125.82435553583026 L214.6459773942278 119.23163413688327 L209.7876965870164 114.79541043298428 L216.19711553865704 114.21007539154617 L218.68478921687574 108.0024441258555 L221.1870966062454 114.2254798488949 L227.59651555788605 114.81081489033302 L222.73823475067462 119.24703859423201 L224.2015723726324 125.839759993179 L218.68478921687574 122.32774882642696 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-1189b" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_15" class="path firer commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="242.74" dataY="101.69"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.26675243915497" height="29.266752439155088" viewBox="242.7362022141735 101.68698716746388 29.26675243915497 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_15-1189b" d="M272.00295465332846 112.83915984961413 L261.4815570677194 111.88413949951777 L257.369578433751 101.68698716746388 L253.2575991020088 111.89954358961717 L242.7362022141735 112.83915984961413 L250.7260256858847 120.12504088095217 L248.32615218125065 130.95373960661897 L257.369578433751 125.20821470131412 L266.41300538402504 130.95373960661897 L264.02776506721165 120.12504088095217 L272.00295465332846 112.83915984961413 Z M257.369578433751 122.32774882642696 L251.8674289891453 125.82435553583026 L253.33076661110306 119.23163413688327 L248.47248580389166 114.79541043298428 L254.8819047555323 114.21007539154617 L257.369578433751 108.0024441258555 L259.87188582312064 114.2254798488949 L266.2813047747613 114.81081489033302 L261.42302396754985 119.24703859423201 L262.8863615895076 125.839759993179 L257.369578433751 122.32774882642696 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-1189b" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;