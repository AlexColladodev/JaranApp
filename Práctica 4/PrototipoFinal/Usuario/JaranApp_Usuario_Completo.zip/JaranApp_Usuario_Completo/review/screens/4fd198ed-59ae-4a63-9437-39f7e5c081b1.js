var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-4fd198ed-59ae-4a63-9437-39f7e5c081b1" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="InicioUsuario"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/4fd198ed-59ae-4a63-9437-39f7e5c081b1/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/4fd198ed-59ae-4a63-9437-39f7e5c081b1/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Mejores Establecimientos"   datasizewidth="226.38px" datasizeheight="22.00px" dataX="66.81" dataY="49.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Mejores Establecimientos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="20.00px" datasizeheight="20.00px" datasizewidthpx="20.000000000000114" datasizeheightpx="20.000000000000114" dataX="196.91" dataY="174.70" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="10.000000000000057" cy="10.000000000000057" rx="10.000000000000057" ry="10.000000000000057">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="10.000000000000057" cy="10.000000000000057" rx="10.000000000000057" ry="10.000000000000057">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="200.00px" datasizeheight="156.00px" datasizewidthpx="200.0" datasizeheightpx="156.00000000000006" dataX="23.00" dataY="88.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento 1"   datasizewidth="126.29px" datasizeheight="18.00px" dataX="27.00" dataY="200.51" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Establecimiento 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_129" class="path firer commentable non-processed" customid="Location On"   datasizewidth="5.00px" datasizeheight="7.14px" dataX="31.17" dataY="230.86"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="5.0" height="7.142857142857167" viewBox="31.166015625000014 230.85714285714283 5.0 7.142857142857167" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_129-4fd19" d="M33.666015625000014 230.85714285714283 C32.283872808728916 230.85714285714283 31.166015625000014 231.97500004087175 31.166015625000014 233.35714285714283 C31.166015625000014 235.23214285714286 33.666015625000014 238.0 33.666015625000014 238.0 C33.666015625000014 238.0 36.166015625000014 235.23214285714286 36.166015625000014 233.35714285714283 C36.166015625000014 231.97500004087175 35.04815844127111 230.85714285714283 33.666015625000014 230.85714285714283 Z M33.666015625000014 234.25 C33.17315848384586 234.25 32.77315848214287 233.849999998297 32.77315848214287 233.35714285714283 C32.77315848214287 232.8642857159887 33.17315848384586 232.4642857142857 33.666015625000014 232.4642857142857 C34.15887276615417 232.4642857142857 34.55887276785715 232.8642857159887 34.55887276785715 233.35714285714283 C34.55887276785715 233.849999998297 34.15887276615417 234.25 33.666015625000014 234.25 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_129-4fd19" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="Calle &Aacute;ngel Ganivet, 12"   datasizewidth="84.05px" datasizeheight="9.00px" dataX="39.88" dataY="229.93" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Calle &Aacute;ngel Ganivet, 12</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext autofit firer ie-background commentable non-processed" customid="Text"   datasizewidth="1.00px" datasizeheight="1.00px" dataX="57.61" dataY="233.06" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_11" class="path firer commentable non-processed" customid="Star"   datasizewidth="7.00px" datasizeheight="7.14px" dataX="30.17" dataY="220.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="7.140000000000001" viewBox="30.166015625000014 220.0 7.0 7.140000000000001" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_11-4fd19" d="M33.666015625000014 225.73830543518068 L35.82901573181154 227.14 L35.25501573681833 224.49819992115624 L37.166015625000014 222.7207157034623 L34.649515604972855 222.49148411913922 L33.666015625000014 220.0 L32.68251547813417 222.491484253532 L30.166015625000014 222.7207157034623 L32.077015638351455 224.49819992115624 L31.503015685081497 227.14 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-4fd19" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_6" class="richtext manualfit firer ie-background commentable non-processed" customid="4.7"   datasizewidth="11.00px" datasizeheight="18.00px" dataX="39.88" dataY="219.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">4.7</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="richtext autofit firer ie-background commentable non-processed" customid="(200+)"   datasizewidth="25.44px" datasizeheight="9.00px" dataX="53.61" dataY="219.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">(200+)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Establecimiento3"   datasizewidth="194.50px" datasizeheight="110.51px" dataX="25.69" dataY="90.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e1dfdd4f-69c8-46e0-a0a0-6e72cb38245e.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Path_365" class="path firer commentable non-processed" customid="Walk"   datasizewidth="7.00px" datasizeheight="12.00px" dataX="188.22" dataY="203.51"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="12.0" viewBox="188.21875000000009 203.51025641025632 7.0 12.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_365-4fd19" d="M192.25721153846163 205.7428145497912 C192.84951924360723 205.7428145497912 193.3341346153847 205.24048898170292 193.3341346153847 204.62653548002376 C193.3341346153847 204.01258197834457 192.84951924360723 203.51025641025632 192.25721153846163 203.51025641025632 C191.664903833316 203.51025641025632 191.18028846153854 204.01258197834457 191.18028846153854 204.62653548002376 C191.18028846153854 205.24048898170292 191.664903833316 205.7428145497912 192.25721153846163 205.7428145497912 Z M190.26490394885732 207.64048875548252 L188.75721153846163 215.51025641025632 L189.88798071787917 215.51025641025632 L190.85721146143408 211.04514013118654 L191.98798064085162 212.161419200954 L191.98798064085162 215.51025641025632 L193.0649037177747 215.51025641025632 L193.0649037177747 211.3242098986284 L191.93413453835717 210.20793082886098 L192.257211474272 208.5335122242098 C192.957211641165 209.3707215265354 194.03413420457116 209.9288610614191 195.21875000000009 209.9288610614191 L195.21875000000009 208.81258199165165 C194.1956730897611 208.81258199165165 193.3341346153847 208.25444245676795 192.90336528191207 207.4730470547024 L192.36490374345055 206.58002378558137 C192.14951912485645 206.24514005134404 191.826442204989 206.02188425069764 191.44951910239007 206.02188425069764 C191.28798063443264 206.02188425069764 191.1802883331593 206.0776982050177 191.0187498652019 206.0776982050177 L188.21875000000009 207.3056053539223 L188.21875000000009 209.9288610614191 L189.29567307692315 209.9288610614191 L189.29567307692315 208.03118685572778 L190.26490382047808 207.64048918796274 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_365-4fd19" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="4 min"   datasizewidth="19.56px" datasizeheight="9.00px" dataX="197.34" dataY="206.51" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">4 min</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_8" class="richtext autofit firer ie-background commentable non-processed" customid="En vivo, Karaoke..."   datasizewidth="67.14px" datasizeheight="9.00px" dataX="149.76" dataY="229.93" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_8_0">En vivo, Karaoke...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="200.00px" datasizeheight="156.00px" datasizewidthpx="200.0" datasizeheightpx="156.00000000000006" dataX="244.19" dataY="88.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_9" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento 2"   datasizewidth="126.29px" datasizeheight="18.00px" dataX="248.19" dataY="200.51" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_9_0">Establecimiento 2</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_10" class="richtext autofit firer ie-background commentable non-processed" customid="Pedro Antonio, 23"   datasizewidth="64.05px" datasizeheight="9.00px" dataX="261.07" dataY="229.93" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_10_0">Pedro Antonio, 23</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="Star"   datasizewidth="7.00px" datasizeheight="7.14px" dataX="251.35" dataY="220.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="7.140000000000001" viewBox="251.3515624999999 219.99999999999997 7.0 7.140000000000001" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-4fd19" d="M254.8515624999999 225.73830543518062 L257.0145626068114 227.14 L256.4405626118182 224.4981999211562 L258.3515624999999 222.72071570346228 L255.83506247997272 222.4914841191392 L254.8515624999999 219.99999999999997 L253.86806235313404 222.49148425353198 L251.3515624999999 222.72071570346228 L253.26256251335133 224.4981999211562 L252.68856256008138 227.14 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-4fd19" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_11" class="richtext manualfit firer ie-background commentable non-processed" customid="4.7"   datasizewidth="12.00px" datasizeheight="18.00px" dataX="261.07" dataY="219.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_11_0">4.7</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_12" class="richtext autofit firer ie-background commentable non-processed" customid="(200+)"   datasizewidth="25.44px" datasizeheight="9.00px" dataX="274.79" dataY="219.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_12_0">(200+)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Walk"   datasizewidth="7.00px" datasizeheight="12.00px" dataX="409.40" dataY="203.51"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="12.0" viewBox="409.404296875 203.5102564102563 7.0 12.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-4fd19" d="M413.44275841346155 205.74281454979118 C414.0350661186072 205.74281454979118 414.51968149038464 205.2404889817029 414.51968149038464 204.62653548002373 C414.51968149038464 204.01258197834454 414.0350661186072 203.5102564102563 413.44275841346155 203.5102564102563 C412.8504507083159 203.5102564102563 412.36583533653845 204.01258197834454 412.36583533653845 204.62653548002373 C412.36583533653845 205.2404889817029 412.8504507083159 205.74281454979118 413.44275841346155 205.74281454979118 Z M411.45045082385724 207.6404887554825 L409.94275841346155 215.5102564102563 L411.0735275928791 215.5102564102563 L412.042758336434 211.0451401311865 L413.17352751585156 212.16141920095396 L413.17352751585156 215.5102564102563 L414.2504505927746 215.5102564102563 L414.2504505927746 211.3242098986284 L413.11968141335706 210.20793082886095 L413.4427583492719 208.53351222420977 C414.1427585161649 209.37072152653536 415.21968107957105 209.92886106141907 416.404296875 209.92886106141907 L416.404296875 208.81258199165163 C415.381219964761 208.81258199165163 414.51968149038464 208.25444245676792 414.088912156912 207.47304705470236 L413.55045061845044 206.58002378558135 C413.33506599985634 206.245140051344 413.0119890799889 206.0218842506976 412.63506597739 206.0218842506976 C412.4735275094326 206.0218842506976 412.36583520815924 206.07769820501767 412.2042967402018 206.07769820501767 L409.404296875 207.30560535392226 L409.404296875 209.92886106141907 L410.4812199519231 209.92886106141907 L410.4812199519231 208.03118685572775 L411.450450695478 207.64048918796271 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-4fd19" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_13" class="richtext autofit firer ie-background commentable non-processed" customid="12 min"   datasizewidth="24.01px" datasizeheight="9.00px" dataX="417.36" dataY="205.01" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_13_0">12 min</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_14" class="richtext autofit firer ie-background commentable non-processed" customid="Discoteca, Latino"   datasizewidth="61.37px" datasizeheight="9.00px" dataX="370.95" dataY="229.93" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_14_0">Discoteca, Latino</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Establecimiento2Webp"   datasizewidth="194.50px" datasizeheight="110.51px" dataX="246.87" dataY="90.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c287c73e-3beb-417c-8936-c232bdd8dfde.jpeg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Para ti"   datasizewidth="66.33px" datasizeheight="24.00px" dataX="23.00" dataY="261.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Para ti</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Recientes"   datasizewidth="66.33px" datasizeheight="24.00px" dataX="107.95" dataY="261.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Recientes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer commentable non-processed" customid="M&aacute;s visitados"   datasizewidth="66.33px" datasizeheight="24.00px" dataX="192.90" dataY="261.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">M&aacute;s visitados</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_4" class="button multiline manualfit firer commentable non-processed" customid="Low cost"   datasizewidth="66.33px" datasizeheight="24.00px" dataX="277.85" dataY="261.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0">Low cost</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="23.00" dataY="300.98" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer click commentable non-processed" customid="Home"   datasizewidth="25.58px" datasizeheight="24.65px" dataX="36.26" dataY="730.92"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.58119658119638" height="24.649999999999864" viewBox="36.25506339303118 730.9237563187232 25.58119658119638 24.649999999999864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-4fd19" d="M46.48754202550973 755.5737563187231 L46.48754202550973 746.8737563187232 L51.60378134174901 746.8737563187232 L51.60378134174901 755.5737563187231 L57.999080487048104 755.5737563187231 L57.999080487048104 743.9737563187232 L61.83625997422756 743.9737563187232 L49.04566168362937 730.9237563187232 L36.25506339303118 743.9737563187232 L40.092242880210634 743.9737563187232 L40.092242880210634 755.5737563187231 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-4fd19" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer click commentable non-processed" customid="Event"   datasizewidth="23.02px" datasizeheight="29.00px" dataX="223.00" dataY="728.75"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.02307692307693" height="29.0" viewBox="222.99779843576562 728.7487563187233 23.02307692307693 29.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-4fd19" d="M240.90463604260324 744.6987563187233 L234.50933689730408 744.6987563187233 L234.50933689730408 751.9487563187233 L240.90463604260324 751.9487563187233 L240.90463604260324 744.6987563187233 Z M239.6255762135434 728.7487563187233 L239.6255762135434 731.6487563187233 L229.39309758106475 731.6487563187233 L229.39309758106475 728.7487563187233 L226.83497792294511 728.7487563187233 L226.83497792294511 731.6487563187233 L225.55591809388528 731.6487563187233 C224.13616166533177 731.6487563187233 223.01058902185815 732.9537562841526 223.01058902185815 734.5487563187232 L222.99779843576562 754.8487563187233 C222.99779843576562 756.443756353294 224.13616166533177 757.7487563187233 225.55591809388528 757.7487563187233 L243.46275570072288 757.7487563187233 C244.86972154318386 757.7487563187233 246.02087535884255 756.443756353294 246.02087535884255 754.8487563187233 L246.02087535884255 734.5487563187232 C246.02087535884255 732.9537562841526 244.86972154318386 731.6487563187233 243.46275570072288 731.6487563187233 L242.18369587166305 731.6487563187233 L242.18369587166305 728.7487563187233 L239.6255762135434 728.7487563187233 Z M243.46275570072288 754.8487563187233 L225.55591809388528 754.8487563187233 L225.55591809388528 738.8987563187233 L243.46275570072288 738.8987563187233 L243.46275570072288 754.8487563187233 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-4fd19" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer commentable non-processed" customid="Search"   datasizewidth="22.37px" datasizeheight="25.36px" dataX="130.91" dataY="730.57"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.370756117502907" height="25.360499624907906" viewBox="130.90549074345864 730.5685065062695 22.370756117502907 25.360499624907906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-4fd19" d="M146.89373860670656 746.5185065062694 L145.88328131430364 746.5185065062694 L145.52514456064213 746.1270064907127 C146.7786230269221 744.4740067275219 147.53326852123647 742.3280060084514 147.53326852123647 739.9935065062695 C147.53326852123647 734.788006285017 143.8112046138414 730.5685065062695 139.21937963234757 730.5685065062695 C134.6275546508537 730.5685065062695 130.90549074345864 734.788006285017 130.90549074345864 739.9935065062695 C130.90549074345864 745.1990067275219 134.6275546508537 749.4185065062694 139.21937963234757 749.4185065062694 C141.27866597543098 749.4185065062694 143.17167439435985 748.5630065442972 144.62980273366676 747.1420064302139 L144.97514890123574 747.5480064319424 L144.97514890123574 748.6935064630561 L151.3704480465349 755.9290061311774 L153.27624686096155 753.7685065062694 L146.89373860670656 746.5185065062694 Z M139.21937963234757 746.5185065062694 C136.03452095074212 746.5185065062694 133.4636104015783 743.6040061743909 133.4636104015783 739.9935065062695 C133.4636104015783 736.3830068381482 136.03452095074212 733.4685065062695 139.21937963234757 733.4685065062695 C142.404238313953 733.4685065062695 144.9751488631168 736.3830068381482 144.9751488631168 739.9935065062695 C144.9751488631168 743.6040061743909 142.404238313953 746.5185065062694 139.21937963234757 746.5185065062694 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-4fd19" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer click commentable non-processed" customid="User"   datasizewidth="20.46px" datasizeheight="23.20px" dataX="315.09" dataY="731.65"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.46495726495732" height="23.199999999999704" viewBox="315.0901061280735 731.6487563187239 20.46495726495732 23.199999999999704" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-4fd19" d="M325.32258476055216 743.2487563187237 C328.14930703156665 743.2487563187237 330.4388240767915 740.6532563740369 330.4388240767915 737.4487563187239 C330.4388240767915 734.2442562634108 328.14930703156665 731.6487563187239 325.32258476055216 731.6487563187239 C322.49586248953767 731.6487563187239 320.20634544431283 734.2442562634108 320.20634544431283 737.4487563187239 C320.20634544431283 740.6532563740369 322.49586248953767 743.2487563187237 325.32258476055216 743.2487563187237 Z M325.32258476055216 746.1487563187237 C321.9074949193779 746.1487563187237 315.0901061280735 748.0917563671227 315.0901061280735 751.9487563187237 L315.0901061280735 754.8487563187236 L335.5550633930308 754.8487563187236 L335.5550633930308 751.9487563187237 C335.5550633930308 748.0917561942692 328.73767460172644 746.1487563187237 325.32258476055216 746.1487563187237 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-4fd19" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="Establecimiento1"   datasizewidth="92.04px" datasizeheight="80.00px" dataX="25.69" dataY="303.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/66bfae75-402a-47b0-9543-cd867d07214c.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_16" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento A"   datasizewidth="127.58px" datasizeheight="18.00px" dataX="122.76" dataY="309.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_16_0">Establecimiento A</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer commentable non-processed" customid="Star"   datasizewidth="7.00px" datasizeheight="7.14px" dataX="295.30" dataY="373.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="7.140000000000001" viewBox="295.3027343749998 373.0 7.0 7.140000000000001" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-4fd19" d="M298.8027343749998 378.7383054351807 L300.9657344818113 380.14 L300.3917344868181 377.49819992115624 L302.3027343749998 375.7207157034623 L299.78623435497263 375.4914841191392 L298.8027343749998 373.0 L297.81923422813395 375.491484253532 L295.3027343749998 375.7207157034623 L297.2137343883512 377.49819992115624 L296.63973443508127 380.14 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-4fd19" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_17" class="richtext manualfit firer ie-background commentable non-processed" customid="4.2"   datasizewidth="12.00px" datasizeheight="18.00px" dataX="305.02" dataY="372.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_17_0">4.2</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_18" class="richtext autofit firer ie-background commentable non-processed" customid="(200+)"   datasizewidth="22.14px" datasizeheight="9.00px" dataX="318.74" dataY="372.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_18_0">(200+)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer commentable non-processed" customid="Location On"   datasizewidth="5.00px" datasizeheight="7.14px" dataX="122.73" dataY="372.93"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="5.0" height="7.142857142857167" viewBox="122.72606837606777 372.92857142857144 5.0 7.142857142857167" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-4fd19" d="M125.22606837606777 372.92857142857144 C123.84392555979667 372.92857142857144 122.72606837606777 374.04642861230036 122.72606837606777 375.42857142857144 C122.72606837606777 377.30357142857144 125.22606837606777 380.0714285714286 125.22606837606777 380.0714285714286 C125.22606837606777 380.0714285714286 127.72606837606777 377.30357142857144 127.72606837606777 375.42857142857144 C127.72606837606777 374.04642861230036 126.60821119233887 372.92857142857144 125.22606837606777 372.92857142857144 Z M125.22606837606777 376.3214285714286 C124.73321123491363 376.3214285714286 124.33321123321063 375.9214285697256 124.33321123321063 375.42857142857144 C124.33321123321063 374.9357142874173 124.73321123491363 374.53571428571433 125.22606837606777 374.53571428571433 C125.71892551722192 374.53571428571433 126.11892551892491 374.9357142874173 126.11892551892491 375.42857142857144 C126.11892551892491 375.9214285697256 125.71892551722192 376.3214285714286 125.22606837606777 376.3214285714286 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-4fd19" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_19" class="richtext manualfit firer ie-background commentable non-processed" customid="C. Periodista Daniel Sauc"   datasizewidth="147.53px" datasizeheight="18.00px" dataX="131.44" dataY="372.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_19_0">C. Periodista Daniel Saucedo Aranda</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_20" class="richtext manualfit firer ie-background commentable non-processed" customid="Chill, Bar, Karaoke"   datasizewidth="128.06px" datasizeheight="26.00px" dataX="122.76" dataY="332.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_20_0">Chill, Bar, Karaoke</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="23.00" dataY="400.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Establecimiento1"   datasizewidth="92.04px" datasizeheight="80.00px" dataX="25.69" dataY="402.02"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/66bfae75-402a-47b0-9543-cd867d07214c.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_21" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento B"   datasizewidth="127.26px" datasizeheight="18.00px" dataX="122.76" dataY="408.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_21_0">Establecimiento B</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_9" class="path firer commentable non-processed" customid="Star"   datasizewidth="7.00px" datasizeheight="7.14px" dataX="295.30" dataY="472.02"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="7.140000000000001" viewBox="295.3027343749997 472.018994566449 7.0 7.140000000000001" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_9-4fd19" d="M298.8027343749997 477.7573000016297 L300.96573448181124 479.158994566449 L300.39173448681805 476.51719448760525 L302.3027343749997 474.7397102699113 L299.7862343549726 474.5104786855882 L298.8027343749997 472.018994566449 L297.8192342281339 474.510478819981 L295.3027343749997 474.7397102699113 L297.21373438835116 476.51719448760525 L296.6397344350812 479.158994566449 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-4fd19" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_22" class="richtext manualfit firer ie-background commentable non-processed" customid="4.2"   datasizewidth="12.00px" datasizeheight="18.00px" dataX="305.02" dataY="471.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_22_0">4.2</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_23" class="richtext autofit firer ie-background commentable non-processed" customid="(200+)"   datasizewidth="22.14px" datasizeheight="9.00px" dataX="318.74" dataY="471.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_23_0">(200+)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_10" class="path firer commentable non-processed" customid="Location On"   datasizewidth="5.00px" datasizeheight="7.14px" dataX="122.73" dataY="471.95"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="5.0" height="7.142857142857167" viewBox="122.72606837606769 471.94756599502045 5.0 7.142857142857167" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_10-4fd19" d="M125.22606837606769 471.94756599502045 C123.84392555979659 471.94756599502045 122.72606837606769 473.06542317874937 122.72606837606769 474.44756599502045 C122.72606837606769 476.32256599502045 125.22606837606769 479.0904231378776 125.22606837606769 479.0904231378776 C125.22606837606769 479.0904231378776 127.72606837606769 476.32256599502045 127.72606837606769 474.44756599502045 C127.72606837606769 473.06542317874937 126.60821119233879 471.94756599502045 125.22606837606769 471.94756599502045 Z M125.22606837606769 475.3404231378776 C124.73321123491354 475.3404231378776 124.33321123321055 474.9404231361746 124.33321123321055 474.44756599502045 C124.33321123321055 473.9547088538663 124.73321123491354 473.55470885216334 125.22606837606769 473.55470885216334 C125.71892551722183 473.55470885216334 126.11892551892483 473.9547088538663 126.11892551892483 474.44756599502045 C126.11892551892483 474.9404231361746 125.71892551722183 475.3404231378776 125.22606837606769 475.3404231378776 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-4fd19" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_24" class="richtext manualfit firer ie-background commentable non-processed" customid="C. Pedro Antonio, 1"   datasizewidth="147.53px" datasizeheight="18.00px" dataX="131.44" dataY="471.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_24_0">C. Pedro Antonio, 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_25" class="richtext manualfit firer ie-background commentable non-processed" customid="Discoteca, Karaoke, Chill"   datasizewidth="136.47px" datasizeheight="26.00px" dataX="122.76" dataY="431.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_25_0">Discoteca, Karaoke, Chill</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="23.00" dataY="500.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_5" class="image firer ie-background commentable non-processed" customid="Establecimiento1"   datasizewidth="92.04px" datasizeheight="80.00px" dataX="25.69" dataY="502.02"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/66bfae75-402a-47b0-9543-cd867d07214c.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_26" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento C"   datasizewidth="127.68px" datasizeheight="18.00px" dataX="122.76" dataY="508.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_26_0">Establecimiento C</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_12" class="path firer commentable non-processed" customid="Star"   datasizewidth="7.00px" datasizeheight="7.14px" dataX="295.30" dataY="572.02"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="7.140000000000001" viewBox="295.30273437499966 572.018994566449 7.0 7.140000000000001" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_12-4fd19" d="M298.80273437499966 577.7573000016297 L300.9657344818112 579.158994566449 L300.391734486818 576.5171944876053 L302.30273437499966 574.7397102699113 L299.7862343549725 574.5104786855883 L298.80273437499966 572.018994566449 L297.81923422813384 574.510478819981 L295.30273437499966 574.7397102699113 L297.2137343883511 576.5171944876053 L296.63973443508115 579.158994566449 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-4fd19" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_27" class="richtext manualfit firer ie-background commentable non-processed" customid="4.1"   datasizewidth="12.00px" datasizeheight="18.00px" dataX="305.02" dataY="571.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_27_0">4.1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_28" class="richtext autofit firer ie-background commentable non-processed" customid="(200+)"   datasizewidth="22.14px" datasizeheight="9.00px" dataX="318.74" dataY="571.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_28_0">(200+)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_13" class="path firer commentable non-processed" customid="Location On"   datasizewidth="5.00px" datasizeheight="7.14px" dataX="122.73" dataY="571.95"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="5.0" height="7.142857142857167" viewBox="122.72606837606766 571.9475659950205 5.0 7.142857142857167" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_13-4fd19" d="M125.22606837606766 571.9475659950205 C123.84392555979656 571.9475659950205 122.72606837606766 573.0654231787494 122.72606837606766 574.4475659950205 C122.72606837606766 576.3225659950205 125.22606837606766 579.0904231378777 125.22606837606766 579.0904231378777 C125.22606837606766 579.0904231378777 127.72606837606766 576.3225659950205 127.72606837606766 574.4475659950205 C127.72606837606766 573.0654231787494 126.60821119233876 571.9475659950205 125.22606837606766 571.9475659950205 Z M125.22606837606766 575.3404231378776 C124.73321123491351 575.3404231378776 124.33321123321052 574.9404231361747 124.33321123321052 574.4475659950205 C124.33321123321052 573.9547088538664 124.73321123491351 573.5547088521633 125.22606837606766 573.5547088521633 C125.7189255172218 573.5547088521633 126.1189255189248 573.9547088538664 126.1189255189248 574.4475659950205 C126.1189255189248 574.9404231361747 125.7189255172218 575.3404231378776 125.22606837606766 575.3404231378776 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-4fd19" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_29" class="richtext manualfit firer ie-background commentable non-processed" customid="C. Pavaneras, 12"   datasizewidth="147.53px" datasizeheight="18.00px" dataX="131.44" dataY="571.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_29_0">C. Pavaneras, 12</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_30" class="richtext manualfit firer ie-background commentable non-processed" customid="Discoteca, Reggaeton"   datasizewidth="121.42px" datasizeheight="26.00px" dataX="122.76" dataY="531.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_30_0">Discoteca, Reggaeton</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="23.00" dataY="599.19" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_6" class="image firer ie-background commentable non-processed" customid="Establecimiento1"   datasizewidth="92.04px" datasizeheight="80.00px" dataX="25.69" dataY="601.21"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/66bfae75-402a-47b0-9543-cd867d07214c.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_31" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento D"   datasizewidth="128.90px" datasizeheight="18.00px" dataX="122.76" dataY="607.21" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_31_0">Establecimiento D</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_14" class="path firer commentable non-processed" customid="Star"   datasizewidth="7.00px" datasizeheight="7.14px" dataX="295.30" dataY="671.21"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="7.140000000000001" viewBox="295.30273437499966 671.2104415267618 7.0 7.140000000000001" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_14-4fd19" d="M298.80273437499966 676.9487469619424 L300.9657344818112 678.3504415267618 L300.391734486818 675.708641447918 L302.30273437499966 673.931157230224 L299.7862343549725 673.701925645901 L298.80273437499966 671.2104415267618 L297.81923422813384 673.7019257802938 L295.30273437499966 673.931157230224 L297.2137343883511 675.708641447918 L296.63973443508115 678.3504415267618 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-4fd19" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_32" class="richtext manualfit firer ie-background commentable non-processed" customid="4.2"   datasizewidth="12.00px" datasizeheight="18.00px" dataX="305.02" dataY="670.21" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_32_0">4.2</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_33" class="richtext autofit firer ie-background commentable non-processed" customid="(200+)"   datasizewidth="22.14px" datasizeheight="9.00px" dataX="318.74" dataY="670.21" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_33_0">(200+)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_15" class="path firer commentable non-processed" customid="Location On"   datasizewidth="5.00px" datasizeheight="7.14px" dataX="122.73" dataY="671.14"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="5.0" height="7.142857142857167" viewBox="122.72606837606766 671.1390129553332 5.0 7.142857142857167" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_15-4fd19" d="M125.22606837606766 671.1390129553332 C123.84392555979656 671.1390129553332 122.72606837606766 672.2568701390621 122.72606837606766 673.6390129553332 C122.72606837606766 675.5140129553332 125.22606837606766 678.2818700981904 125.22606837606766 678.2818700981904 C125.22606837606766 678.2818700981904 127.72606837606766 675.5140129553332 127.72606837606766 673.6390129553332 C127.72606837606766 672.2568701390621 126.60821119233876 671.1390129553332 125.22606837606766 671.1390129553332 Z M125.22606837606766 674.5318700981903 C124.73321123491351 674.5318700981903 124.33321123321052 674.1318700964874 124.33321123321052 673.6390129553332 C124.33321123321052 673.1461558141791 124.73321123491351 672.7461558124761 125.22606837606766 672.7461558124761 C125.7189255172218 672.7461558124761 126.1189255189248 673.1461558141791 126.1189255189248 673.6390129553332 C126.1189255189248 674.1318700964874 125.7189255172218 674.5318700981903 125.22606837606766 674.5318700981903 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-4fd19" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_34" class="richtext manualfit firer ie-background commentable non-processed" customid="P. Realejo 1"   datasizewidth="147.53px" datasizeheight="18.00px" dataX="131.44" dataY="670.21" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_34_0">P. Realejo 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_35" class="richtext manualfit firer ie-background commentable non-processed" customid="Karaoke, Bar, Chill"   datasizewidth="103.31px" datasizeheight="26.00px" dataX="122.76" dataY="630.21" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_35_0">Karaoke, Bar, Chill</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_7" class="image firer ie-background commentable non-processed" customid="EstablecimientoB"   datasizewidth="92.04px" datasizeheight="80.00px" dataX="25.69" dataY="502.02"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/910b19a2-eac6-4cf8-9e6e-5eb9eaa3ab3e.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_8" class="image firer ie-background commentable non-processed" customid="EstablecimientoC"   datasizewidth="92.04px" datasizeheight="80.00px" dataX="25.69" dataY="601.21"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/237efb12-fd2b-4e77-90a6-854ab2b932e5.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_9" class="image firer ie-background commentable non-processed" customid="EstablecimientoX"   datasizewidth="92.04px" datasizeheight="80.00px" dataX="25.69" dataY="402.02"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4d6876c9-96e9-487d-8b18-da33f93ba918.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="200.00px" datasizeheight="156.00px" dataX="23.00" dataY="88.00"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Status bar light" datasizewidth="360.00px" datasizeheight="34.00px" dataX="0.00" dataY="0.00" >\
        <div id="s-Panel_1" class="panel default firer commentable non-processed" customid="Panel"  datasizewidth="360.00px" datasizeheight="34.00px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_16" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_16_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_98" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_98-4fd19" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_98-4fd19" fill="#FFFFFF" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_104" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_104-4fd19" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_104-4fd19" fill="#FFFFFF" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
                  <div id="s-Path_16" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_16-4fd19" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-4fd19" fill="#FFFFFF" fill-opacity="0.3"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_17" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_17-4fd19" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-4fd19" fill="#FFFFFF" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Paragraph_49" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_49_0">9:30</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;