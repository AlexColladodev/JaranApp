var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-1b6cf767-c424-42c6-abc7-a45fd636baa9" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Detalle Usuario"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/1b6cf767-c424-42c6-abc7-a45fd636baa9/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/1b6cf767-c424-42c6-abc7-a45fd636baa9/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-1b6cf" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-1b6cf" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-1b6cf" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-1b6cf" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_9" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_9-1b6cf" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-1b6cf" fill="#FFFFFF" fill-opacity="0.3"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_10" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_10-1b6cf" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-1b6cf" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_6" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">9:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="8.23" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="8.227257896035209 51.0 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-1b6cf" d="M30.22725789603521 60.625 L13.493507791131034 60.625 L21.179758000939383 52.93874979019165 L19.22725789603521 51.0 L8.227257896035209 62.0 L19.22725789603521 73.0 L21.166007850139632 71.06125004589558 L13.493507791131034 63.375 L30.22725789603521 63.375 L30.22725789603521 60.625 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-1b6cf" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Share"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="317.00" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="317.0 51.00000000000004 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-1b6cf" d="M335.3333333333333 66.55020089547844 C334.40444445610046 66.55020089547844 333.5733332633972 66.88152620659717 332.9377777311537 67.40060247249285 L324.22333314683704 62.81726907881679 C324.28444425885874 62.56325301244479 324.333333151208 62.309236946072794 324.333333151208 62.04417673009202 C324.333333151208 61.77911651411124 324.2844442634119 61.525100431282134 324.22333314683704 61.271084381367245 L332.8400000466241 56.731927651954734 C333.5000000728501 57.284136481876494 334.36777782440186 57.62650595906112 335.3333333333333 57.62650595906112 C337.36222218142615 57.62650595906112 339.0 56.14658625800689 339.0 54.31325297953058 C339.0 52.479919701054264 337.36222218142615 51.00000000000004 335.3333333333333 51.00000000000004 C333.30444448524054 51.00000000000004 331.6666666666667 52.479919701054264 331.6666666666667 54.31325297953058 C331.6666666666667 54.578313211968464 331.7155555544628 54.83232927834047 331.7766666710377 55.086345328255355 L323.1599999533759 59.62550271595208 C322.5 59.07329388603033 321.63222217559814 58.730923948046744 320.6666666666667 58.730923948046744 C318.63777781857385 58.730923948046744 317.0 60.210843649100966 317.0 62.04417692757728 C317.0 63.8775102060536 318.63777781857385 65.35742990710781 320.6666666666667 65.35742990710781 C321.6322222484483 65.35742990710781 322.5 65.0150604299232 323.1599999533759 64.46285160000144 L331.8622220357259 69.05722889642969 C331.8011109237042 69.2891565977557 331.76444426013364 69.53212849806181 331.76444426013364 69.7751003489966 C331.76444426013364 71.55321279714349 333.36555530130863 73.00000000000004 335.33333324227067 73.00000000000004 C337.3011110375325 73.00000000000004 338.90222222440775 71.55321292880032 338.90222222440775 69.7751003489966 C338.90222222440775 67.99698776919288 337.3011111832327 66.55020069799316 335.33333324227067 66.55020069799316 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-1b6cf" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Perfil"   datasizewidth="225.18px" datasizeheight="20.00px" dataX="37.87" dataY="52.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">Perfil</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="189.00px" datasizeheight="185.00px" datasizewidthpx="189.0" datasizeheightpx="185.0" dataX="87.69" dataY="110.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="94.5" cy="92.5" rx="94.5" ry="92.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="94.5" cy="92.5" rx="94.5" ry="92.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Path_11" class="path firer click commentable non-processed" customid="Home"   datasizewidth="25.58px" datasizeheight="24.65px" dataX="28.41" dataY="813.17"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.58119658119638" height="24.649999999999864" viewBox="28.412500000000126 813.1749999999998 25.58119658119638 24.649999999999864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_11-1b6cf" d="M38.644978632478676 837.8249999999997 L38.644978632478676 829.1249999999998 L43.761217948717956 829.1249999999998 L43.761217948717956 837.8249999999997 L50.15651709401705 837.8249999999997 L50.15651709401705 826.2249999999998 L53.9936965811965 826.2249999999998 L41.20309829059832 813.1749999999998 L28.412500000000126 826.2249999999998 L32.249679487179584 826.2249999999998 L32.249679487179584 837.8249999999997 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-1b6cf" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_12" class="path firer click commentable non-processed" customid="Event"   datasizewidth="23.02px" datasizeheight="29.00px" dataX="215.16" dataY="811.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.02307692307693" height="29.0" viewBox="215.15523504273455 810.9999999999999 23.02307692307693 29.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_12-1b6cf" d="M233.06207264957217 826.9499999999999 L226.666773504273 826.9499999999999 L226.666773504273 834.1999999999999 L233.06207264957217 834.1999999999999 L233.06207264957217 826.9499999999999 Z M231.78301282051234 810.9999999999999 L231.78301282051234 813.8999999999999 L221.55053418803368 813.8999999999999 L221.55053418803368 810.9999999999999 L218.99241452991404 810.9999999999999 L218.99241452991404 813.8999999999999 L217.7133547008542 813.8999999999999 C216.2935982723007 813.8999999999999 215.16802562882708 815.2049999654292 215.16802562882708 816.7999999999998 L215.15523504273455 837.0999999999999 C215.15523504273455 838.6950000345706 216.2935982723007 839.9999999999999 217.7133547008542 839.9999999999999 L235.6201923076918 839.9999999999999 C237.0271581501528 839.9999999999999 238.17831196581147 838.6950000345706 238.17831196581147 837.0999999999999 L238.17831196581147 816.7999999999998 C238.17831196581147 815.2049999654292 237.0271581501528 813.8999999999999 235.6201923076918 813.8999999999999 L234.34113247863198 813.8999999999999 L234.34113247863198 810.9999999999999 L231.78301282051234 810.9999999999999 Z M235.6201923076918 837.0999999999999 L217.7133547008542 837.0999999999999 L217.7133547008542 821.1499999999999 L235.6201923076918 821.1499999999999 L235.6201923076918 837.0999999999999 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-1b6cf" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_13" class="path firer commentable non-processed" customid="Search"   datasizewidth="22.37px" datasizeheight="25.36px" dataX="123.06" dataY="812.82"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.370756117502907" height="25.360499624907906" viewBox="123.06292735042759 812.8197501875461 22.370756117502907 25.360499624907906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_13-1b6cf" d="M139.0511752136755 828.769750187546 L138.04071792127257 828.769750187546 L137.68258116761106 828.3782501719893 C138.93605963389106 826.7252504087985 139.6907051282054 824.579249689728 139.6907051282054 822.2447501875461 C139.6907051282054 817.0392499662937 135.96864122081033 812.8197501875461 131.3768162393165 812.8197501875461 C126.78499125782265 812.8197501875461 123.06292735042759 817.0392499662937 123.06292735042759 822.2447501875461 C123.06292735042759 827.4502504087985 126.78499125782265 831.669750187546 131.3768162393165 831.669750187546 C133.4361025823999 831.669750187546 135.32911100132878 830.8142502255738 136.78723934063572 829.3932501114905 L137.1325855082047 829.799250113219 L137.1325855082047 830.9447501443327 L143.52788465350386 838.180249812454 L145.4336834679305 836.019750187546 L139.0511752136755 828.769750187546 Z M131.3768162393165 828.769750187546 C128.19195755771108 828.769750187546 125.62104700854725 825.8552498556674 125.62104700854725 822.2447501875461 C125.62104700854725 818.6342505194248 128.19195755771108 815.7197501875461 131.3768162393165 815.7197501875461 C134.56167492092192 815.7197501875461 137.13258547008573 818.6342505194248 137.13258547008573 822.2447501875461 C137.13258547008573 825.8552498556674 134.56167492092192 828.769750187546 131.3768162393165 828.769750187546 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-1b6cf" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_14" class="path firer click commentable non-processed" customid="User"   datasizewidth="20.46px" datasizeheight="23.20px" dataX="307.25" dataY="813.90"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.46495726495732" height="23.199999999999704" viewBox="307.2475427350425 813.9000000000005 20.46495726495732 23.199999999999704" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_14-1b6cf" d="M317.48002136752115 825.5000000000005 C320.30674363853564 825.5000000000005 322.5962606837605 822.9045000553135 322.5962606837605 819.7000000000005 C322.5962606837605 816.4954999446874 320.30674363853564 813.9000000000005 317.48002136752115 813.9000000000005 C314.65329909650666 813.9000000000005 312.3637820512818 816.4954999446874 312.3637820512818 819.7000000000005 C312.3637820512818 822.9045000553135 314.65329909650666 825.5000000000005 317.48002136752115 825.5000000000005 Z M317.48002136752115 828.4000000000003 C314.06493152634687 828.4000000000003 307.2475427350425 830.3430000483993 307.2475427350425 834.2000000000003 L307.2475427350425 837.1000000000003 L327.7124999999998 837.1000000000003 L327.7124999999998 834.2000000000003 C327.7124999999998 830.3429998755458 320.8951112086954 828.4000000000003 317.48002136752115 828.4000000000003 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-1b6cf" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_16" class="path firer commentable non-processed" customid="Edit"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="283.50" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.000000000000004" viewBox="283.5000000000001 50.99999999999992 22.0 22.000000000000004" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_16-1b6cf" d="M283.5000000000001 68.41730312897361 L283.5000000000001 72.99999999999993 L288.08269708344693 72.99999999999993 L301.59859769557966 59.48409884892604 L297.01590061213284 54.90140197789974 L283.5000000000001 68.41730312897361 Z M305.14254964060245 55.940147068175065 C305.6191501197993 55.46354661106993 305.6191501197993 54.69365354256471 305.14254964060245 54.217053085459575 L302.28294676542123 51.35745034282877 C301.80634628622437 50.880849885723634 301.0364531820325 50.880849885723634 300.55985270283566 51.35745034282877 L298.3234964736688 53.593806468334414 L302.9061935571156 58.176503339360714 L305.1425497862825 55.94014721385508 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-1b6cf" fill="#666666" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="315.50px" datasizeheight="43.00px" datasizewidthpx="315.4999999999999" datasizeheightpx="43.000000000000114" dataX="22.25" dataY="360.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext autofit firer click ie-background commentable non-processed" customid="Seguidos"   datasizewidth="63.26px" datasizeheight="18.00px" dataX="61.06" dataY="521.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Seguidos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext manualfit firer click ie-background commentable non-processed" customid="Seguidores"   datasizewidth="88.78px" datasizeheight="18.00px" dataX="229.06" dataY="521.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Seguidores</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="Edwin Yueng Weng"   datasizewidth="220.22px" datasizeheight="29.00px" dataX="69.89" dataY="318.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Edwin Yueng Weng</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Nombre de usuario"   datasizewidth="119.94px" datasizeheight="17.00px" dataX="27.72" dataY="365.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Nombre de usuario</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Edwin_Yueng_1962"   datasizewidth="119.94px" datasizeheight="17.00px" dataX="27.72" dataY="381.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Edwin_Yueng_1962</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="315.50px" datasizeheight="43.00px" datasizewidthpx="315.4999999999999" datasizeheightpx="43.000000000000114" dataX="22.25" dataY="413.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_8" class="richtext manualfit firer ie-background commentable non-processed" customid="Fecha de nacimiento"   datasizewidth="119.94px" datasizeheight="17.00px" dataX="27.72" dataY="418.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_8_0">Fecha de nacimiento</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_9" class="richtext manualfit firer ie-background commentable non-processed" customid="24 de enero de 1962"   datasizewidth="119.94px" datasizeheight="17.00px" dataX="27.72" dataY="434.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_9_0">24 de enero de 1962</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="315.50px" datasizeheight="43.00px" datasizewidthpx="315.4999999999999" datasizeheightpx="43.000000000000114" dataX="22.25" dataY="464.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_10" class="richtext manualfit firer ie-background commentable non-processed" customid="Correo electr&oacute;nico"   datasizewidth="119.94px" datasizeheight="17.00px" dataX="27.72" dataY="469.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_10_0">Correo electr&oacute;nico</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_11" class="richtext manualfit firer ie-background commentable non-processed" customid="edwin_yueng@yahoo.com"   datasizewidth="142.94px" datasizeheight="26.00px" dataX="27.72" dataY="485.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_11_0">edwin_yueng@yahoo.com</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_12" class="richtext autofit firer click ie-background commentable non-processed" customid="23"   datasizewidth="21.40px" datasizeheight="22.00px" dataX="83.72" dataY="550.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_12_0">23</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_13" class="richtext autofit firer click ie-background commentable non-processed" customid="35"   datasizewidth="21.40px" datasizeheight="22.00px" dataX="262.75" dataY="550.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_13_0">35</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="deportes"   datasizewidth="46.26px" datasizeheight="46.26px" dataX="63.41" dataY="598.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/eb6499d0-5c95-41d2-ae54-6e9e8be408f3.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="chill"   datasizewidth="56.14px" datasizeheight="56.14px" dataX="152.32" dataY="598.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/ef47e134-7ff3-42b8-98fe-a53c7094a213.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="karaoke"   datasizewidth="56.14px" datasizeheight="56.14px" dataX="58.48" dataY="698.53"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/51437bd9-b021-40f8-8de0-dc3b093bca08.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="rock"   datasizewidth="56.14px" datasizeheight="56.14px" dataX="251.11" dataY="598.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/a11a031f-ef8d-43dd-ac48-9447bee394aa.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="image firer ie-background commentable non-processed" customid="bar"   datasizewidth="56.14px" datasizeheight="56.14px" dataX="152.32" dataY="698.53"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/1b05d295-30cc-44f6-83c9-a26801b31911.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_14" class="richtext autofit firer ie-background commentable non-processed" customid="Deportes"   datasizewidth="48.69px" datasizeheight="13.00px" dataX="62.20" dataY="656.40" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_14_0">Deportes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_15" class="richtext autofit firer ie-background commentable non-processed" customid="Chill"   datasizewidth="23.34px" datasizeheight="13.00px" dataX="168.72" dataY="656.40" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_15_0">Chill</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_16" class="richtext autofit firer ie-background commentable non-processed" customid="Karaoke"   datasizewidth="44.70px" datasizeheight="13.00px" dataX="64.20" dataY="757.38" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_16_0">Karaoke</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_17" class="richtext autofit firer ie-background commentable non-processed" customid="Bar"   datasizewidth="18.67px" datasizeheight="13.00px" dataX="171.05" dataY="757.38" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_17_0">Bar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_18" class="richtext autofit firer ie-background commentable non-processed" customid="Rock"   datasizewidth="27.34px" datasizeheight="13.00px" dataX="265.51" dataY="656.85" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_18_0">Rock</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="200.00px" datasizeheight="23.00px" datasizewidthpx="199.9999999999999" datasizeheightpx="23.0" dataX="71.05" dataY="840.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;