var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-a7f04495-14b9-4cff-a1ac-d7e5eba837e6" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="DetallesEstablecimiento 2"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/a7f04495-14b9-4cff-a1ac-d7e5eba837e6/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/a7f04495-14b9-4cff-a1ac-d7e5eba837e6/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Path_3" class="path firer commentable non-processed" customid="Location On"   datasizewidth="14.00px" datasizeheight="20.00px" dataX="15.00" dataY="311.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="20.0" viewBox="15.0 311.00000000000017 14.0 20.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-a7f04" d="M22.0 311.00000000000017 C18.130000114440918 311.00000000000017 15.0 314.1300001144411 15.0 318.00000000000017 C15.0 323.25000000000017 22.0 331.00000000000017 22.0 331.00000000000017 C22.0 331.00000000000017 29.0 323.25000000000017 29.0 318.00000000000017 C29.0 314.1300001144411 25.869999885559082 311.00000000000017 22.0 311.00000000000017 Z M22.0 320.50000000000017 C20.62000000476837 320.50000000000017 19.5 319.3799999952318 19.5 318.00000000000017 C19.5 316.62000000476854 20.62000000476837 315.50000000000017 22.0 315.50000000000017 C23.37999999523163 315.50000000000017 24.5 316.62000000476854 24.5 318.00000000000017 C24.5 319.3799999952318 23.37999999523163 320.50000000000017 22.0 320.50000000000017 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="17.09" dataY="445.27" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="69.00px" datasizeheight="69.00px" dataX="22.45" dataY="451.99"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="resources/jim/images/common/cross.svg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Path_8" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="8.23" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="8.227257896035209 51.0 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-a7f04" d="M30.22725789603521 60.625 L13.493507791131034 60.625 L21.179758000939383 52.93874979019165 L19.22725789603521 51.0 L8.227257896035209 62.0 L19.22725789603521 73.0 L21.166007850139632 71.06125004589558 L13.493507791131034 63.375 L30.22725789603521 63.375 L30.22725789603521 60.625 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_5" class="image firer ie-background commentable non-processed" customid="Establecimiento3"   datasizewidth="343.55px" datasizeheight="180.27px" dataX="8.23" dataY="87.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/8b840a4e-4815-4bf3-b1cc-66b61461eeaf.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento 1"   datasizewidth="205.30px" datasizeheight="29.00px" dataX="15.00" dataY="276.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Establecimiento 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_70" class="path firer commentable non-processed" customid="Favorite Outline"   datasizewidth="20.00px" datasizeheight="18.35px" dataX="274.00" dataY="281.32"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="18.350000381469727" viewBox="274.0 281.32499980926536 20.0 18.350000381469727" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_70-a7f04" d="M288.5 281.32499980926536 C286.75999999046326 281.32499980926536 285.0899999141693 282.13499981164955 284.0 283.4149997234347 C282.9099998474121 282.1349997520449 281.23999977111816 281.32499980926536 279.5 281.32499980926536 C276.42000007629395 281.32499980926536 274.0 283.7449998855593 274.0 286.82499980926536 C274.0 290.60499978065513 277.40000009536743 293.68499994277977 282.55000019073486 298.3649997711184 L284.0 299.6750001907351 L285.4500000476837 298.355000138283 C290.6000003814697 293.6849994659426 294.0 290.60499954223656 294.0 286.82499980926536 C294.0 283.7449998855593 291.57999992370605 281.32499980926536 288.5 281.32499980926536 Z M284.09999990463257 296.8750000000002 L283.99999990314245 296.97500000149034 L283.89999990165234 296.8750000000002 C279.1399998664856 292.5649995803835 276.0 289.7150001525881 276.0 286.82499980926536 C276.0 284.82499980926536 277.5 283.32499980926536 279.5 283.32499980926536 C281.039999961853 283.32499980926536 282.539999961853 284.3149998188021 283.0699999332428 285.6849997043612 L284.93999993801117 285.6849997043612 C285.460000038147 284.3149995803835 286.960000038147 283.32499980926536 288.5 283.32499980926536 C290.5 283.32499980926536 292.0 284.82499980926536 292.0 286.82499980926536 C292.0 289.71499991416954 288.8599998950958 292.5649995803835 284.09999990463257 296.8750000000002 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_70-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_52" class="path firer commentable non-processed" customid="Bookmark Outline"   datasizewidth="14.00px" datasizeheight="18.00px" dataX="315.00" dataY="281.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="18.0" viewBox="315.00000000000034 281.50000000000034 14.0 18.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_52-a7f04" d="M327.00000000000034 281.50000000000034 L317.00000000000034 281.50000000000034 C315.8999999761585 281.50000000000034 315.00000000000034 282.3999999761585 315.00000000000034 283.50000000000034 L315.00000000000034 299.50000000000034 L322.00000000000034 296.50000000000034 L329.00000000000034 299.50000000000034 L329.00000000000034 283.50000000000034 C329.00000000000034 282.3999999761585 328.1000000238422 281.50000000000034 327.00000000000034 281.50000000000034 Z M327.00000000000034 296.50000000000034 L322.00000000000034 294.31999993324314 L317.00000000000034 296.50000000000034 L317.00000000000034 283.50000000000034 L327.00000000000034 283.50000000000034 L327.00000000000034 296.50000000000034 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_52-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Calle &Aacute;ngel Ganivet, 12"   datasizewidth="147.09px" datasizeheight="16.00px" dataX="32.91" dataY="313.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Calle &Aacute;ngel Ganivet, 12</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="Star"   datasizewidth="18.00px" datasizeheight="20.00px" dataX="260.28" dataY="310.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.0" height="20.0" viewBox="260.28124999999994 309.99999999999994 18.0 20.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-a7f04" d="M269.28124999999994 326.07368469238276 L274.84325027465815 329.99999999999994 L273.3672502875327 322.5999997791491 L278.28124999999994 317.6210523906506 L271.8102499485015 316.97894711243475 L269.28124999999994 309.99999999999994 L266.7522496223449 316.9789474888851 L260.28124999999994 317.6210523906506 L265.1952500343322 322.5999997791491 L263.71925015449517 329.99999999999994 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-a7f04" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="4.7"   datasizewidth="21.96px" datasizeheight="34.00px" dataX="278.28" dataY="313.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">4.7</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext autofit firer ie-background commentable non-processed" customid="(200+)"   datasizewidth="38.74px" datasizeheight="16.00px" dataX="300.24" dataY="313.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">(200+)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Ofertas"   datasizewidth="113.55px" datasizeheight="41.08px" dataX="47.36" dataY="390.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Ofertas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Eventos"   datasizewidth="113.55px" datasizeheight="41.08px" dataX="199.09" dataY="390.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Eventos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_173" class="path firer commentable non-processed" customid="Share"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="317.00" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="317.0 51.00000000000004 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_173-a7f04" d="M335.3333333333333 66.55020089547844 C334.40444445610046 66.55020089547844 333.5733332633972 66.88152620659717 332.9377777311537 67.40060247249285 L324.22333314683704 62.81726907881679 C324.28444425885874 62.56325301244479 324.333333151208 62.309236946072794 324.333333151208 62.04417673009202 C324.333333151208 61.77911651411124 324.2844442634119 61.525100431282134 324.22333314683704 61.271084381367245 L332.8400000466241 56.731927651954734 C333.5000000728501 57.284136481876494 334.36777782440186 57.62650595906112 335.3333333333333 57.62650595906112 C337.36222218142615 57.62650595906112 339.0 56.14658625800689 339.0 54.31325297953058 C339.0 52.479919701054264 337.36222218142615 51.00000000000004 335.3333333333333 51.00000000000004 C333.30444448524054 51.00000000000004 331.6666666666667 52.479919701054264 331.6666666666667 54.31325297953058 C331.6666666666667 54.578313211968464 331.7155555544628 54.83232927834047 331.7766666710377 55.086345328255355 L323.1599999533759 59.62550271595208 C322.5 59.07329388603033 321.63222217559814 58.730923948046744 320.6666666666667 58.730923948046744 C318.63777781857385 58.730923948046744 317.0 60.210843649100966 317.0 62.04417692757728 C317.0 63.8775102060536 318.63777781857385 65.35742990710781 320.6666666666667 65.35742990710781 C321.6322222484483 65.35742990710781 322.5 65.0150604299232 323.1599999533759 64.46285160000144 L331.8622220357259 69.05722889642969 C331.8011109237042 69.2891565977557 331.76444426013364 69.53212849806181 331.76444426013364 69.7751003489966 C331.76444426013364 71.55321279714349 333.36555530130863 73.00000000000004 335.33333324227067 73.00000000000004 C337.3011110375325 73.00000000000004 338.90222222440775 71.55321292880032 338.90222222440775 69.7751003489966 C338.90222222440775 67.99698776919288 337.3011111832327 66.55020069799316 335.33333324227067 66.55020069799316 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_173-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="84.46px" datasizeheight="36.00px" datasizewidthpx="84.45556640624993" datasizeheightpx="35.99999999999994" dataX="17.09" dataY="341.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_9" class="image firer ie-background commentable non-processed" customid="en_vivo"   datasizewidth="24.17px" datasizeheight="24.04px" dataX="26.99" dataY="347.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/0df351b8-af47-4acd-ae7f-19d2c89c4e81.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="En vivo"   datasizewidth="34.62px" datasizeheight="12.00px" dataX="59.09" dataY="353.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">En vivo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="84.46px" datasizeheight="36.00px" datasizewidthpx="84.45556640624993" datasizeheightpx="35.99999999999994" dataX="112.04" dataY="341.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_6" class="image firer ie-background commentable non-processed" customid="karaoke"   datasizewidth="24.04px" datasizeheight="24.04px" dataX="121.93" dataY="347.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/51437bd9-b021-40f8-8de0-dc3b093bca08.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Karaoke"   datasizewidth="42.23px" datasizeheight="24.00px" dataX="149.00" dataY="353.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">Karaoke</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="84.46px" datasizeheight="36.00px" datasizewidthpx="84.45556640624993" datasizeheightpx="35.99999999999994" dataX="207.00" dataY="341.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_7" class="image firer ie-background commentable non-processed" customid="chill"   datasizewidth="24.04px" datasizeheight="24.04px" dataX="216.82" dataY="347.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/ef47e134-7ff3-42b8-98fe-a53c7094a213.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Chill"   datasizewidth="42.23px" datasizeheight="24.00px" dataX="247.03" dataY="353.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Chill</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_8" class="image firer click ie-background commentable non-processed" customid="DALL&middot;E-2025-01-06-23.51"   datasizewidth="69.00px" datasizeheight="69.00px" dataX="22.45" dataY="450.50"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c53e17a3-3d08-48f8-af2d-86f8ce639901.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_9" class="richtext manualfit firer click ie-background commentable non-processed" customid="&iexcl;Vive una noche aterrador"   datasizewidth="235.92px" datasizeheight="36.00px" dataX="98.18" dataY="485.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_9_0">&iexcl;Vive una noche aterradora llena de m&uacute;sica, luces y diversi&oacute;n! Disfruta de una fiesta tem&aacute;tica con ambiente espeluznante, DJ en vivo y sorpresas para una experiencia inolvidable.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_14" class="richtext autofit firer click ie-background commentable non-processed" customid="Halloween Party - Precio:"   datasizewidth="242.45px" datasizeheight="18.00px" dataX="98.18" dataY="456.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_14_0">Halloween Party - Precio: 20 euros</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-a7f04" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-a7f04" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_9" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_9-a7f04" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-a7f04" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_10" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_10-a7f04" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-a7f04" fill="#FFFFFF" fill-opacity="0.3"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_11" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_11-a7f04" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-a7f04" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_8" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_8_0">9:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_16" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento 1"   datasizewidth="142.13px" datasizeheight="20.00px" dataX="37.87" dataY="52.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_16_0">Establecimiento 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer click commentable non-processed" customid="Home"   datasizewidth="25.58px" datasizeheight="24.65px" dataX="28.37" dataY="834.68"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.58119658119638" height="24.649999999999864" viewBox="28.36776234619553 834.675 25.58119658119638 24.649999999999864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-a7f04" d="M38.60024097867408 859.3249999999998 L38.60024097867408 850.6249999999999 L43.71648029491336 850.6249999999999 L43.71648029491336 859.3249999999998 L50.11177944021245 859.3249999999998 L50.11177944021245 847.7249999999999 L53.948958927391914 847.7249999999999 L41.158360636793724 834.675 L28.36776234619553 847.7249999999999 L32.20494183337499 847.7249999999999 L32.20494183337499 859.3249999999998 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer click commentable non-processed" customid="Event"   datasizewidth="23.02px" datasizeheight="29.00px" dataX="215.11" dataY="832.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.02307692307693" height="29.0" viewBox="215.11049738892999 832.5 23.02307692307693 29.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-a7f04" d="M233.0173349957676 848.45 L226.62203585046845 848.45 L226.62203585046845 855.7 L233.0173349957676 855.7 L233.0173349957676 848.45 Z M231.73827516670778 832.5 L231.73827516670778 835.4 L221.50579653422912 835.4 L221.50579653422912 832.5 L218.94767687610948 832.5 L218.94767687610948 835.4 L217.66861704704965 835.4 C216.24886061849614 835.4 215.12328797502252 836.7049999654294 215.12328797502252 838.3 L215.11049738892999 858.6 C215.11049738892999 860.1950000345707 216.24886061849614 861.5 217.66861704704965 861.5 L235.57545465388725 861.5 C236.98242049634823 861.5 238.1335743120069 860.1950000345707 238.1335743120069 858.6 L238.1335743120069 838.3 C238.1335743120069 836.7049999654294 236.98242049634823 835.4 235.57545465388725 835.4 L234.29639482482742 835.4 L234.29639482482742 832.5 L231.73827516670778 832.5 Z M235.57545465388725 858.6 L217.66861704704965 858.6 L217.66861704704965 842.65 L235.57545465388725 842.65 L235.57545465388725 858.6 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer commentable non-processed" customid="Search"   datasizewidth="22.37px" datasizeheight="25.36px" dataX="123.02" dataY="834.32"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.370756117502907" height="25.360499624907906" viewBox="123.018189696623 834.3197501875461 22.370756117502907 25.360499624907906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-a7f04" d="M139.0064375598709 850.269750187546 L137.99598026746798 850.269750187546 L137.63784351380647 849.8782501719893 C138.89132198008647 848.2252504087985 139.6459674744008 846.079249689728 139.6459674744008 843.7447501875461 C139.6459674744008 838.5392499662937 135.92390356700574 834.3197501875461 131.3320785855119 834.3197501875461 C126.74025360401806 834.3197501875461 123.018189696623 838.5392499662937 123.018189696623 843.7447501875461 C123.018189696623 848.9502504087985 126.74025360401806 853.169750187546 131.3320785855119 853.169750187546 C133.39136492859532 853.169750187546 135.2843733475242 852.3142502255738 136.74250168683113 850.8932501114905 L137.0878478544001 851.299250113219 L137.0878478544001 852.4447501443327 L143.48314699969927 859.680249812454 L145.38894581412592 857.519750187546 L139.0064375598709 850.269750187546 Z M131.3320785855119 850.269750187546 C128.1472199039065 850.269750187546 125.57630935474266 847.3552498556674 125.57630935474266 843.7447501875461 C125.57630935474266 840.1342505194248 128.1472199039065 837.2197501875461 131.3320785855119 837.2197501875461 C134.51693726711733 837.2197501875461 137.08784781628114 840.1342505194248 137.08784781628114 843.7447501875461 C137.08784781628114 847.3552498556674 134.51693726711733 850.269750187546 131.3320785855119 850.269750187546 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer click commentable non-processed" customid="User"   datasizewidth="20.46px" datasizeheight="23.20px" dataX="307.20" dataY="835.40"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.46495726495732" height="23.199999999999704" viewBox="307.20280508123784 835.4000000000005 20.46495726495732 23.199999999999704" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-a7f04" d="M317.4352837137165 847.0000000000005 C320.262005984731 847.0000000000005 322.55152302995583 844.4045000553135 322.55152302995583 841.2000000000005 C322.55152302995583 837.9954999446874 320.262005984731 835.4000000000005 317.4352837137165 835.4000000000005 C314.608561442702 835.4000000000005 312.31904439747717 837.9954999446874 312.31904439747717 841.2000000000005 C312.31904439747717 844.4045000553135 314.608561442702 847.0000000000005 317.4352837137165 847.0000000000005 Z M317.4352837137165 849.9000000000003 C314.0201938725422 849.9000000000003 307.20280508123784 851.8430000483993 307.20280508123784 855.7000000000003 L307.20280508123784 858.6000000000003 L327.66776234619516 858.6000000000003 L327.66776234619516 855.7000000000003 C327.66776234619516 851.8429998755458 320.8503735548908 849.9000000000003 317.4352837137165 849.9000000000003 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_12" class="path firer commentable non-processed" customid="Star"   datasizewidth="15.00px" datasizeheight="15.00px" dataX="28.05" dataY="666.51"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="15.0" viewBox="28.046954498966624 666.5089776523158 15.0 15.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_12-a7f04" d="M35.54695449896663 678.5642411716029 L40.18195472784846 681.5089776523158 L38.9519547385773 675.9589774866777 L43.04695449896663 672.2247669453038 L37.65445445605128 671.7431879866419 L35.54695449896663 666.5089776523158 L33.4394541842541 671.7431882689797 L28.046954498966624 672.2247669453038 L32.14195452757686 675.9589774866777 L30.911954627712657 681.5089776523158 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-a7f04" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_13" class="path firer commentable non-processed" customid="Star"   datasizewidth="15.00px" datasizeheight="15.00px" dataX="44.55" dataY="666.51"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="15.0" viewBox="44.54695449896663 666.5089776523158 15.0 15.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_13-a7f04" d="M52.04695449896663 678.5642411716029 L56.68195472784846 681.5089776523158 L55.4519547385773 675.9589774866777 L59.54695449896663 672.2247669453038 L54.15445445605128 671.7431879866419 L52.04695449896663 666.5089776523158 L49.9394541842541 671.7431882689797 L44.54695449896663 672.2247669453038 L48.64195452757686 675.9589774866777 L47.41195462771266 681.5089776523158 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-a7f04" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_14" class="path firer commentable non-processed" customid="Star"   datasizewidth="15.00px" datasizeheight="15.00px" dataX="61.05" dataY="666.51"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="15.0" viewBox="61.04695449896663 666.5089776523158 15.0 15.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_14-a7f04" d="M68.54695449896663 678.5642411716029 L73.18195472784846 681.5089776523158 L71.9519547385773 675.9589774866777 L76.04695449896663 672.2247669453038 L70.65445445605128 671.7431879866419 L68.54695449896663 666.5089776523158 L66.4394541842541 671.7431882689797 L61.04695449896663 672.2247669453038 L65.14195452757686 675.9589774866777 L63.91195462771266 681.5089776523158 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-a7f04" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_15" class="path firer ie-background commentable non-processed" customid="Account_circle"   datasizewidth="20.00px" datasizeheight="20.00px" dataX="81.39" dataY="664.01"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="20.0" viewBox="81.39276234619497 664.0089776523158 20.0 20.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_15-a7f04" d="M91.39276234619497 664.0089776523158 C85.87276236526846 664.0089776523158 81.39276234619497 668.4889776713893 81.39276234619497 674.0089776523158 C81.39276234619497 679.5289776332423 85.87276236526846 684.0089776523158 91.39276234619497 684.0089776523158 C96.91276232712148 684.0089776523158 101.39276234619497 679.5289776332423 101.39276234619497 674.0089776523158 C101.39276234619497 668.4889776713893 96.91276280395864 664.0089776523158 91.39276234619497 664.0089776523158 Z M91.39276234619497 667.0089776523158 C93.05276231281637 667.0089776523158 94.39276234619497 668.3489776856944 94.39276234619497 670.0089776523158 C94.39276234619497 671.6689776189372 93.05276231281637 673.0089776523158 91.39276234619497 673.0089776523158 C89.73276237957357 673.0089776523158 88.39276234619497 671.6689776189372 88.39276234619497 670.0089776523158 C88.39276234619497 668.3489776856944 89.73276237957357 667.0089776523158 91.39276234619497 667.0089776523158 Z M91.39276234619497 681.208977461581 C88.89276234619497 681.208977461581 86.682762308048 679.9289774901912 85.39276234619497 677.9889774329707 C85.42276234552442 675.998977423434 89.39276234619497 674.9089775092647 91.39276234619497 674.9089775092647 C93.38276235573171 674.9089775092647 97.36276213638662 675.9989775426433 97.39276234619497 677.9889774329707 C96.10276238434194 679.9289774901912 93.89276234619497 681.208977461581 91.39276234619497 681.208977461581 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-a7f04" fill="none"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_10" class="richtext autofit firer ie-background commentable non-processed" customid="Ver todas"   datasizewidth="67.14px" datasizeheight="18.00px" dataX="263.50" dataY="766.51" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_10_0">Ver todas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_16" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="88.01" dataY="613.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.26675243915518" height="29.266752439155088" viewBox="88.01480769286691 613.4301763664666 29.26675243915518 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_16-a7f04" d="M117.2815601320221 624.582349048617 L106.76016254641296 623.6273286985205 L102.6481839124445 613.4301763664666 L98.5362045807023 623.6427327886199 L88.01480769286691 624.582349048617 L96.00463116457817 631.868230079955 L93.6047576599441 642.6969288056217 L102.6481839124445 636.9514039003169 L111.69161086271866 642.6969288056217 L109.30637054590525 631.868230079955 L117.2815601320221 624.582349048617 Z M102.6481839124445 634.0709380254297 L97.1460344678388 637.5675447348331 L98.60937208979657 630.9748233358861 L93.75109128258512 626.538599631987 L100.16051023422581 625.9532645905489 L102.6481839124445 619.7456333248583 L105.15049130181417 625.9686690478977 L111.55991025345486 626.5540040893358 L106.70162944624343 630.9902277932348 L108.16496706820118 637.5829491921818 L102.6481839124445 634.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_17" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="126.70" dataY="613.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.266752439155184" height="29.266752439155088" viewBox="126.6995969097423 613.4301763664666 29.266752439155184 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_17-a7f04" d="M155.9663493488975 624.582349048617 L145.44495176328834 623.6273286985205 L141.3329731293199 613.4301763664666 L137.22099379757768 623.6427327886199 L126.6995969097423 624.582349048617 L134.68942038145357 631.868230079955 L132.2895468768195 642.6969288056217 L141.3329731293199 636.9514039003169 L150.37640007959405 642.6969288056217 L147.99115976278063 631.868230079955 L155.9663493488975 624.582349048617 Z M141.3329731293199 634.0709380254297 L135.83082368471418 637.5675447348331 L137.29416130667195 630.9748233358861 L132.43588049946052 626.538599631987 L138.8452994511012 625.9532645905489 L141.3329731293199 619.7456333248583 L143.83528051868956 625.9686690478977 L150.24469947033023 626.5540040893358 L145.3864186631188 630.9902277932348 L146.84975628507658 637.5829491921818 L141.3329731293199 634.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_18" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="165.38" dataY="613.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.2667524391551" height="29.266752439155088" viewBox="165.3843861266177 613.4301763664666 29.2667524391551 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_18-a7f04" d="M194.65113856577278 624.582349048617 L184.1297409801637 623.6273286985205 L180.01776234619524 613.4301763664666 L175.90578301445305 623.6427327886199 L165.3843861266177 624.582349048617 L173.37420959832895 631.868230079955 L170.97433609369486 642.6969288056217 L180.01776234619524 636.9514039003169 L189.06118929646937 642.6969288056217 L186.67594897965597 631.868230079955 L194.65113856577278 624.582349048617 Z M180.01776234619524 634.0709380254297 L174.51561290158955 637.5675447348331 L175.97895052354733 630.9748233358861 L171.1206697163359 626.538599631987 L177.53008866797657 625.9532645905489 L180.01776234619524 619.7456333248583 L182.5200697355649 625.9686690478977 L188.92948868720558 626.5540040893358 L184.07120787999415 630.9902277932348 L185.5345455019519 637.5829491921818 L180.01776234619524 634.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_18-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_19" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="204.07" dataY="613.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.266752439155056" height="29.266752439155088" viewBox="204.06917534349304 613.4301763664666 29.266752439155056 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_19-a7f04" d="M233.3359277826481 624.582349048617 L222.814530197039 623.6273286985205 L218.70255156307059 613.4301763664666 L214.5905722313284 623.6427327886199 L204.06917534349304 624.582349048617 L212.0589988152043 631.868230079955 L209.6591253105702 642.6969288056217 L218.70255156307059 636.9514039003169 L227.74597851334468 642.6969288056217 L225.3607381965313 631.868230079955 L233.3359277826481 624.582349048617 Z M218.70255156307059 634.0709380254297 L213.2004021184649 637.5675447348331 L214.66373974042264 630.9748233358861 L209.80545893321124 626.538599631987 L216.2148778848519 625.9532645905489 L218.70255156307059 619.7456333248583 L221.20485895244025 625.9686690478977 L227.6142779040809 626.5540040893358 L222.75599709686946 630.9902277932348 L224.21933471882724 637.5829491921818 L218.70255156307059 634.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_19-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_20" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="242.75" dataY="613.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.26675243915497" height="29.266752439155088" viewBox="242.75396456036833 613.4301763664666 29.26675243915497 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_20-a7f04" d="M272.0207169995233 624.582349048617 L261.49931941391424 623.6273286985205 L257.3873407799458 613.4301763664666 L253.27536144820365 623.6427327886199 L242.75396456036833 624.582349048617 L250.74378803207955 631.868230079955 L248.3439145274455 642.6969288056217 L257.3873407799458 636.9514039003169 L266.4307677302199 642.6969288056217 L264.0455274134065 631.868230079955 L272.0207169995233 624.582349048617 Z M257.3873407799458 634.0709380254297 L251.88519133534015 637.5675447348331 L253.3485289572979 630.9748233358861 L248.4902481500865 626.538599631987 L254.89966710172715 625.9532645905489 L257.3873407799458 619.7456333248583 L259.8896481693155 625.9686690478977 L266.2990671209561 626.5540040893358 L261.4407863137447 630.9902277932348 L262.90412393570244 637.5829491921818 L257.3873407799458 634.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_20-a7f04" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_11" class="richtext autofit firer ie-background commentable non-processed" customid="Calificar y opinar:"   datasizewidth="123.60px" datasizeheight="18.00px" dataX="31.01" dataY="588.43" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_11_0">Calificar y opinar:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_12" class="richtext autofit firer ie-background commentable non-processed" customid="Rese&ntilde;as"   datasizewidth="72.32px" datasizeheight="22.00px" dataX="24.56" dataY="552.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_12_0">Rese&ntilde;as</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="20.00px" datasizeheight="20.00px" datasizewidthpx="20.0" datasizeheightpx="20.0" dataX="78.01" dataY="664.01" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="10.0" cy="10.0" rx="10.0" ry="10.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="10.0" cy="10.0" rx="10.0" ry="10.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Text_13" class="richtext manualfit firer ie-background commentable non-processed" customid="Luis Quispe Huam&aacute;n"   datasizewidth="101.42px" datasizeheight="14.00px" dataX="102.65" dataY="667.01" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_13_0">Luis Quispe Huam&aacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_15" class="richtext manualfit firer ie-background commentable non-processed" customid="El sitio est&aacute; bien para p"   datasizewidth="307.39px" datasizeheight="44.00px" dataX="28.05" dataY="692.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_15_0">El sitio est&aacute; bien para pasar un rato, pero hace un calor insoportable dentro. Necesitan mejorar la ventilaci&oacute;n o el aire acondicionado porque no se puede disfrutar al 100% as&iacute;.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="200.00px" datasizeheight="23.00px" datasizewidthpx="199.9999999999999" datasizeheightpx="23.0" dataX="81.74" dataY="868.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 7"   datasizewidth="316.73px" datasizeheight="88.00px" datasizewidthpx="316.73480962950987" datasizeheightpx="88.0" dataX="21.63" dataY="657.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;