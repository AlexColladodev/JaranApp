var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-667faad0-092e-47b1-a674-178de97be8c5" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="DetallesEstablecimiento"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/667faad0-092e-47b1-a674-178de97be8c5/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/667faad0-092e-47b1-a674-178de97be8c5/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Path_3" class="path firer commentable non-processed" customid="Location On"   datasizewidth="14.00px" datasizeheight="20.00px" dataX="15.00" dataY="311.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="20.0" viewBox="15.0 311.00000000000017 14.0 20.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-667fa" d="M22.0 311.00000000000017 C18.130000114440918 311.00000000000017 15.0 314.1300001144411 15.0 318.00000000000017 C15.0 323.25000000000017 22.0 331.00000000000017 22.0 331.00000000000017 C22.0 331.00000000000017 29.0 323.25000000000017 29.0 318.00000000000017 C29.0 314.1300001144411 25.869999885559082 311.00000000000017 22.0 311.00000000000017 Z M22.0 320.50000000000017 C20.62000000476837 320.50000000000017 19.5 319.3799999952318 19.5 318.00000000000017 C19.5 316.62000000476854 20.62000000476837 315.50000000000017 22.0 315.50000000000017 C23.37999999523163 315.50000000000017 24.5 316.62000000476854 24.5 318.00000000000017 C24.5 319.3799999952318 23.37999999523163 320.50000000000017 22.0 320.50000000000017 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="17.09" dataY="445.27" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="69.00px" datasizeheight="69.00px" dataX="22.45" dataY="451.99"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="resources/jim/images/common/cross.svg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_12" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="17.09" dataY="541.27" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_12_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="69.00px" datasizeheight="69.00px" dataX="22.45" dataY="547.99"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="resources/jim/images/common/cross.svg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_17" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 21"   datasizewidth="325.81px" datasizeheight="84.00px" datasizewidthpx="325.81012678606237" datasizeheightpx="84.00000000000006" dataX="17.09" dataY="635.27" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_17_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="69.00px" datasizeheight="69.00px" dataX="22.45" dataY="641.99"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="resources/jim/images/common/cross.svg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Path_4" class="path firer click commentable non-processed" customid="Home"   datasizewidth="25.58px" datasizeheight="24.65px" dataX="30.35" dataY="1030.68"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.58119658119638" height="24.649999999999864" viewBox="30.350000000000463 1030.675 25.58119658119638 24.649999999999864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-667fa" d="M40.58247863247902 1055.3249999999998 L40.58247863247902 1046.6249999999998 L45.6987179487183 1046.6249999999998 L45.6987179487183 1055.3249999999998 L52.09401709401739 1055.3249999999998 L52.09401709401739 1043.725 L55.93119658119684 1043.725 L43.14059829059865 1030.675 L30.350000000000463 1043.725 L34.18717948717992 1043.725 L34.18717948717992 1055.3249999999998 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer click commentable non-processed" customid="Event"   datasizewidth="23.02px" datasizeheight="29.00px" dataX="217.09" dataY="1028.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.02307692307693" height="29.0" viewBox="217.09273504273492 1028.5 23.02307692307693 29.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-667fa" d="M234.99957264957254 1044.45 L228.60427350427338 1044.45 L228.60427350427338 1051.7 L234.99957264957254 1051.7 L234.99957264957254 1044.45 Z M233.7205128205127 1028.5 L233.7205128205127 1031.4 L223.48803418803405 1031.4 L223.48803418803405 1028.5 L220.9299145299144 1028.5 L220.9299145299144 1031.4 L219.65085470085458 1031.4 C218.23109827230107 1031.4 217.10552562882745 1032.7049999654294 217.10552562882745 1034.3 L217.09273504273492 1054.6 C217.09273504273492 1056.1950000345707 218.23109827230107 1057.5 219.65085470085458 1057.5 L237.55769230769218 1057.5 C238.96465815015316 1057.5 240.11581196581184 1056.1950000345707 240.11581196581184 1054.6 L240.11581196581184 1034.3 C240.11581196581184 1032.7049999654294 238.96465815015316 1031.4 237.55769230769218 1031.4 L236.27863247863235 1031.4 L236.27863247863235 1028.5 L233.7205128205127 1028.5 Z M237.55769230769218 1054.6 L219.65085470085458 1054.6 L219.65085470085458 1038.65 L237.55769230769218 1038.65 L237.55769230769218 1054.6 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer commentable non-processed" customid="Search"   datasizewidth="22.37px" datasizeheight="25.36px" dataX="125.00" dataY="1030.32"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.370756117502907" height="25.360499624907906" viewBox="125.00042735042793 1030.319750187546 22.370756117502907 25.360499624907906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-667fa" d="M140.98867521367583 1046.2697501875462 L139.97821792127291 1046.2697501875462 L139.6200811676114 1045.8782501719893 C140.8735596338914 1044.2252504087985 141.62820512820574 1042.0792496897282 141.62820512820574 1039.744750187546 C141.62820512820574 1034.5392499662937 137.90614122081067 1030.319750187546 133.31431623931684 1030.319750187546 C128.722491257823 1030.319750187546 125.00042735042793 1034.5392499662937 125.00042735042793 1039.744750187546 C125.00042735042793 1044.9502504087984 128.722491257823 1049.169750187546 133.31431623931684 1049.169750187546 C135.37360258240025 1049.169750187546 137.26661100132912 1048.314250225574 138.72473934063606 1046.8932501114905 L139.07008550820504 1047.2992501132192 L139.07008550820504 1048.4447501443326 L145.4653846535042 1055.6802498124541 L147.37118346793085 1053.5197501875462 L140.98867521367583 1046.2697501875462 Z M133.31431623931684 1046.2697501875462 C130.12945755771142 1046.2697501875462 127.55854700854759 1043.3552498556674 127.55854700854759 1039.744750187546 C127.55854700854759 1036.1342505194248 130.12945755771142 1033.2197501875462 133.31431623931684 1033.2197501875462 C136.49917492092226 1033.2197501875462 139.07008547008607 1036.1342505194248 139.07008547008607 1039.744750187546 C139.07008547008607 1043.3552498556674 136.49917492092226 1046.2697501875462 133.31431623931684 1046.2697501875462 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer click commentable non-processed" customid="User"   datasizewidth="20.46px" datasizeheight="23.20px" dataX="309.19" dataY="1031.40"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.46495726495732" height="23.199999999999704" viewBox="309.18504273504277 1031.4000000000005 20.46495726495732 23.199999999999704" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-667fa" d="M319.41752136752143 1043.0000000000005 C322.2442436385359 1043.0000000000005 324.53376068376076 1040.4045000553135 324.53376068376076 1037.2000000000005 C324.53376068376076 1033.9954999446875 322.2442436385359 1031.4000000000005 319.41752136752143 1031.4000000000005 C316.59079909650694 1031.4000000000005 314.3012820512821 1033.9954999446875 314.3012820512821 1037.2000000000005 C314.3012820512821 1040.4045000553135 316.59079909650694 1043.0000000000005 319.41752136752143 1043.0000000000005 Z M319.41752136752143 1045.9000000000003 C316.00243152634715 1045.9000000000003 309.18504273504277 1047.8430000483993 309.18504273504277 1051.7000000000003 L309.18504273504277 1054.6000000000004 L329.6500000000001 1054.6000000000004 L329.6500000000001 1051.7000000000003 C329.6500000000001 1047.8429998755457 322.8326112086957 1045.9000000000003 319.41752136752143 1045.9000000000003 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="8.23" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="8.227257896035209 51.0 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-667fa" d="M30.22725789603521 60.625 L13.493507791131034 60.625 L21.179758000939383 52.93874979019165 L19.22725789603521 51.0 L8.227257896035209 62.0 L19.22725789603521 73.0 L21.166007850139632 71.06125004589558 L13.493507791131034 63.375 L30.22725789603521 63.375 L30.22725789603521 60.625 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_5" class="image firer ie-background commentable non-processed" customid="Establecimiento3"   datasizewidth="343.55px" datasizeheight="180.27px" dataX="8.23" dataY="87.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/8b840a4e-4815-4bf3-b1cc-66b61461eeaf.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento 1"   datasizewidth="205.30px" datasizeheight="29.00px" dataX="15.00" dataY="276.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Establecimiento 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_70" class="path firer commentable non-processed" customid="Favorite Outline"   datasizewidth="20.00px" datasizeheight="18.35px" dataX="274.00" dataY="281.32"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="18.350000381469727" viewBox="274.0 281.32499980926536 20.0 18.350000381469727" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_70-667fa" d="M288.5 281.32499980926536 C286.75999999046326 281.32499980926536 285.0899999141693 282.13499981164955 284.0 283.4149997234347 C282.9099998474121 282.1349997520449 281.23999977111816 281.32499980926536 279.5 281.32499980926536 C276.42000007629395 281.32499980926536 274.0 283.7449998855593 274.0 286.82499980926536 C274.0 290.60499978065513 277.40000009536743 293.68499994277977 282.55000019073486 298.3649997711184 L284.0 299.6750001907351 L285.4500000476837 298.355000138283 C290.6000003814697 293.6849994659426 294.0 290.60499954223656 294.0 286.82499980926536 C294.0 283.7449998855593 291.57999992370605 281.32499980926536 288.5 281.32499980926536 Z M284.09999990463257 296.8750000000002 L283.99999990314245 296.97500000149034 L283.89999990165234 296.8750000000002 C279.1399998664856 292.5649995803835 276.0 289.7150001525881 276.0 286.82499980926536 C276.0 284.82499980926536 277.5 283.32499980926536 279.5 283.32499980926536 C281.039999961853 283.32499980926536 282.539999961853 284.3149998188021 283.0699999332428 285.6849997043612 L284.93999993801117 285.6849997043612 C285.460000038147 284.3149995803835 286.960000038147 283.32499980926536 288.5 283.32499980926536 C290.5 283.32499980926536 292.0 284.82499980926536 292.0 286.82499980926536 C292.0 289.71499991416954 288.8599998950958 292.5649995803835 284.09999990463257 296.8750000000002 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_70-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_52" class="path firer commentable non-processed" customid="Bookmark Outline"   datasizewidth="14.00px" datasizeheight="18.00px" dataX="315.00" dataY="281.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="18.0" viewBox="315.00000000000034 281.50000000000034 14.0 18.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_52-667fa" d="M327.00000000000034 281.50000000000034 L317.00000000000034 281.50000000000034 C315.8999999761585 281.50000000000034 315.00000000000034 282.3999999761585 315.00000000000034 283.50000000000034 L315.00000000000034 299.50000000000034 L322.00000000000034 296.50000000000034 L329.00000000000034 299.50000000000034 L329.00000000000034 283.50000000000034 C329.00000000000034 282.3999999761585 328.1000000238422 281.50000000000034 327.00000000000034 281.50000000000034 Z M327.00000000000034 296.50000000000034 L322.00000000000034 294.31999993324314 L317.00000000000034 296.50000000000034 L317.00000000000034 283.50000000000034 L327.00000000000034 283.50000000000034 L327.00000000000034 296.50000000000034 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_52-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Calle &Aacute;ngel Ganivet, 12"   datasizewidth="147.09px" datasizeheight="16.00px" dataX="32.91" dataY="313.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Calle &Aacute;ngel Ganivet, 12</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="Star"   datasizewidth="18.00px" datasizeheight="20.00px" dataX="260.28" dataY="310.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.0" height="20.0" viewBox="260.28124999999994 309.99999999999994 18.0 20.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-667fa" d="M269.28124999999994 326.07368469238276 L274.84325027465815 329.99999999999994 L273.3672502875327 322.5999997791491 L278.28124999999994 317.6210523906506 L271.8102499485015 316.97894711243475 L269.28124999999994 309.99999999999994 L266.7522496223449 316.9789474888851 L260.28124999999994 317.6210523906506 L265.1952500343322 322.5999997791491 L263.71925015449517 329.99999999999994 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-667fa" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="4.7"   datasizewidth="21.96px" datasizeheight="34.00px" dataX="278.28" dataY="313.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">4.7</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext autofit firer ie-background commentable non-processed" customid="(200+)"   datasizewidth="38.74px" datasizeheight="16.00px" dataX="300.24" dataY="313.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">(200+)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Ofertas"   datasizewidth="113.55px" datasizeheight="41.08px" dataX="47.36" dataY="390.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Ofertas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Eventos"   datasizewidth="113.55px" datasizeheight="41.08px" dataX="199.09" dataY="390.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Eventos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_173" class="path firer commentable non-processed" customid="Share"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="317.00" dataY="51.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="317.0 51.00000000000004 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_173-667fa" d="M335.3333333333333 66.55020089547844 C334.40444445610046 66.55020089547844 333.5733332633972 66.88152620659717 332.9377777311537 67.40060247249285 L324.22333314683704 62.81726907881679 C324.28444425885874 62.56325301244479 324.333333151208 62.309236946072794 324.333333151208 62.04417673009202 C324.333333151208 61.77911651411124 324.2844442634119 61.525100431282134 324.22333314683704 61.271084381367245 L332.8400000466241 56.731927651954734 C333.5000000728501 57.284136481876494 334.36777782440186 57.62650595906112 335.3333333333333 57.62650595906112 C337.36222218142615 57.62650595906112 339.0 56.14658625800689 339.0 54.31325297953058 C339.0 52.479919701054264 337.36222218142615 51.00000000000004 335.3333333333333 51.00000000000004 C333.30444448524054 51.00000000000004 331.6666666666667 52.479919701054264 331.6666666666667 54.31325297953058 C331.6666666666667 54.578313211968464 331.7155555544628 54.83232927834047 331.7766666710377 55.086345328255355 L323.1599999533759 59.62550271595208 C322.5 59.07329388603033 321.63222217559814 58.730923948046744 320.6666666666667 58.730923948046744 C318.63777781857385 58.730923948046744 317.0 60.210843649100966 317.0 62.04417692757728 C317.0 63.8775102060536 318.63777781857385 65.35742990710781 320.6666666666667 65.35742990710781 C321.6322222484483 65.35742990710781 322.5 65.0150604299232 323.1599999533759 64.46285160000144 L331.8622220357259 69.05722889642969 C331.8011109237042 69.2891565977557 331.76444426013364 69.53212849806181 331.76444426013364 69.7751003489966 C331.76444426013364 71.55321279714349 333.36555530130863 73.00000000000004 335.33333324227067 73.00000000000004 C337.3011110375325 73.00000000000004 338.90222222440775 71.55321292880032 338.90222222440775 69.7751003489966 C338.90222222440775 67.99698776919288 337.3011111832327 66.55020069799316 335.33333324227067 66.55020069799316 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_173-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="84.46px" datasizeheight="36.00px" datasizewidthpx="84.45556640624993" datasizeheightpx="35.99999999999994" dataX="17.09" dataY="341.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_9" class="image firer ie-background commentable non-processed" customid="en_vivo"   datasizewidth="24.17px" datasizeheight="24.04px" dataX="26.99" dataY="347.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/0df351b8-af47-4acd-ae7f-19d2c89c4e81.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="En vivo"   datasizewidth="34.62px" datasizeheight="12.00px" dataX="59.09" dataY="353.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">En vivo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="84.46px" datasizeheight="36.00px" datasizewidthpx="84.45556640624993" datasizeheightpx="35.99999999999994" dataX="112.04" dataY="341.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_6" class="image firer ie-background commentable non-processed" customid="karaoke"   datasizewidth="24.04px" datasizeheight="24.04px" dataX="121.93" dataY="347.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/51437bd9-b021-40f8-8de0-dc3b093bca08.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Karaoke"   datasizewidth="42.23px" datasizeheight="24.00px" dataX="149.00" dataY="353.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">Karaoke</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="84.46px" datasizeheight="36.00px" datasizewidthpx="84.45556640624993" datasizeheightpx="35.99999999999994" dataX="207.00" dataY="341.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_7" class="image firer ie-background commentable non-processed" customid="chill"   datasizewidth="24.04px" datasizeheight="24.04px" dataX="216.82" dataY="347.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/ef47e134-7ff3-42b8-98fe-a53c7094a213.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Chill"   datasizewidth="42.23px" datasizeheight="24.00px" dataX="247.03" dataY="353.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Chill</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_8" class="image firer click ie-background commentable non-processed" customid="DALL&middot;E-2025-01-06-23.51"   datasizewidth="69.00px" datasizeheight="69.00px" dataX="22.45" dataY="450.50"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c1ccf1ad-74fc-4e6d-9a2f-e1e2f9821e93.jpeg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_10" class="image firer ie-background commentable non-processed" customid="DALL&middot;E-2025-01-06-23.52"   datasizewidth="69.00px" datasizeheight="69.00px" dataX="22.45" dataY="546.50"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/2dc18334-2912-41bd-921e-e4c4af0147b6.jpeg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_11" class="image firer ie-background commentable non-processed" customid="DALL&middot;E-2025-01-07-00.04"   datasizewidth="69.00px" datasizeheight="69.00px" dataX="21.43" dataY="640.50"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/908ee03f-a578-433c-adb2-c8b1f4204e59.jpeg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_9" class="richtext manualfit firer click ie-background commentable non-processed" customid="Disfruta de la mejor prom"   datasizewidth="235.92px" datasizeheight="40.00px" dataX="98.18" dataY="485.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_9_0">Disfruta de la mejor promoci&oacute;n con tres cervezas al precio de dos por tan solo 5 euros. Ideal para compartir con amigos y disfrutar de una noche inolvidable. &iexcl;La oferta perfecta para calentar motores en el mejor ambiente!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_10" class="richtext manualfit firer ie-background commentable non-processed" customid="&iexcl;No vengas solo! Compra t"   datasizewidth="235.92px" datasizeheight="40.00px" dataX="98.86" dataY="581.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_10_0">&iexcl;No vengas solo! Compra tu entrada y recibe otra totalmente gratis para invitar a quien quieras. Disfruta de la mejor m&uacute;sica, buen ambiente y diversi&oacute;n al doble por el mismo precio.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_11" class="richtext manualfit firer ie-background commentable non-processed" customid="Por cada bebida que compr"   datasizewidth="235.92px" datasizeheight="40.00px" dataX="98.86" dataY="675.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_11_0">Por cada bebida que compres, recibe un shot completamente gratis para celebrar a lo grande. Una oferta pensada para hacer tus noches a&uacute;n m&aacute;s especiales y llenas de sabor.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_12" class="richtext autofit firer ie-background commentable non-processed" customid="2x1 en entradas"   datasizewidth="112.05px" datasizeheight="18.00px" dataX="98.86" dataY="554.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_12_0">2x1 en entradas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_13" class="richtext autofit firer ie-background commentable non-processed" customid="Shot gratis con cada bebi"   datasizewidth="195.46px" datasizeheight="18.00px" dataX="98.86" dataY="645.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_13_0">Shot gratis con cada bebida</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_14" class="richtext autofit firer click ie-background commentable non-processed" customid="3x2 en cervezas - Precio:"   datasizewidth="227.89px" datasizeheight="18.00px" dataX="98.18" dataY="456.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_14_0">3x2 en cervezas - Precio: 5 euros</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-667fa" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-667fa" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_9" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_9-667fa" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-667fa" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_10" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_10-667fa" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-667fa" fill="#FFFFFF" fill-opacity="0.3"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_11" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_11-667fa" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-667fa" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_8" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_8_0">9:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_16" class="richtext autofit firer ie-background commentable non-processed" customid="Establecimiento 1"   datasizewidth="142.13px" datasizeheight="20.00px" dataX="37.87" dataY="52.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_16_0">Establecimiento 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_12" class="path firer commentable non-processed" customid="Star"   datasizewidth="15.00px" datasizeheight="15.00px" dataX="30.03" dataY="862.51"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="15.0" viewBox="30.029192152771557 862.5089776523158 15.0 15.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_12-667fa" d="M37.52919215277156 874.5642411716029 L42.16419238165339 877.5089776523158 L40.93419239238223 871.9589774866777 L45.02919215277156 868.2247669453038 L39.63669210985621 867.7431879866419 L37.52919215277156 862.5089776523158 L35.42169183805903 867.7431882689797 L30.029192152771557 868.2247669453038 L34.12419218138179 871.9589774866777 L32.89419228151759 877.5089776523158 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-667fa" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_13" class="path firer commentable non-processed" customid="Star"   datasizewidth="15.00px" datasizeheight="15.00px" dataX="46.53" dataY="862.51"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="15.0" viewBox="46.52919215277156 862.5089776523158 15.0 15.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_13-667fa" d="M54.02919215277156 874.5642411716029 L58.66419238165339 877.5089776523158 L57.43419239238223 871.9589774866777 L61.52919215277156 868.2247669453038 L56.13669210985621 867.7431879866419 L54.02919215277156 862.5089776523158 L51.92169183805903 867.7431882689797 L46.52919215277156 868.2247669453038 L50.62419218138179 871.9589774866777 L49.39419228151759 877.5089776523158 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-667fa" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_14" class="path firer commentable non-processed" customid="Star"   datasizewidth="15.00px" datasizeheight="15.00px" dataX="63.03" dataY="862.51"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="15.0" viewBox="63.02919215277156 862.5089776523158 15.0 15.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_14-667fa" d="M70.52919215277156 874.5642411716029 L75.1641923816534 877.5089776523158 L73.93419239238223 871.9589774866777 L78.02919215277156 868.2247669453038 L72.63669210985621 867.7431879866419 L70.52919215277156 862.5089776523158 L68.42169183805903 867.7431882689797 L63.02919215277156 868.2247669453038 L67.12419218138179 871.9589774866777 L65.89419228151759 877.5089776523158 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-667fa" fill="#FFC107" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_15" class="path firer ie-background commentable non-processed" customid="Account_circle"   datasizewidth="20.00px" datasizeheight="20.00px" dataX="83.37" dataY="860.01"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="20.0" viewBox="83.3749999999999 860.0089776523158 20.0 20.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_15-667fa" d="M93.3749999999999 860.0089776523158 C87.85500001907339 860.0089776523158 83.3749999999999 864.4889776713893 83.3749999999999 870.0089776523158 C83.3749999999999 875.5289776332423 87.85500001907339 880.0089776523158 93.3749999999999 880.0089776523158 C98.89499998092641 880.0089776523158 103.3749999999999 875.5289776332423 103.3749999999999 870.0089776523158 C103.3749999999999 864.4889776713893 98.89500045776357 860.0089776523158 93.3749999999999 860.0089776523158 Z M93.3749999999999 863.0089776523158 C95.0349999666213 863.0089776523158 96.3749999999999 864.3489776856944 96.3749999999999 866.0089776523158 C96.3749999999999 867.6689776189372 95.0349999666213 869.0089776523158 93.3749999999999 869.0089776523158 C91.7150000333785 869.0089776523158 90.3749999999999 867.6689776189372 90.3749999999999 866.0089776523158 C90.3749999999999 864.3489776856944 91.7150000333785 863.0089776523158 93.3749999999999 863.0089776523158 Z M93.3749999999999 877.208977461581 C90.8749999999999 877.208977461581 88.66499996185293 875.9289774901912 87.3749999999999 873.9889774329707 C87.40499999932935 871.998977423434 91.3749999999999 870.9089775092647 93.3749999999999 870.9089775092647 C95.36500000953664 870.9089775092647 99.34499979019155 871.9989775426433 99.3749999999999 873.9889774329707 C98.08500003814687 875.9289774901912 95.8749999999999 877.208977461581 93.3749999999999 877.208977461581 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-667fa" fill="none"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_15" class="richtext autofit firer ie-background commentable non-processed" customid="Ver todas"   datasizewidth="67.14px" datasizeheight="18.00px" dataX="265.49" dataY="962.51" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_15_0">Ver todas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_17" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="90.00" dataY="809.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.26675243915518" height="29.266752439155088" viewBox="89.99704534667184 809.4301763664666 29.26675243915518 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_17-667fa" d="M119.26379778582702 820.582349048617 L108.74240020021789 819.6273286985205 L104.63042156624942 809.4301763664666 L100.51844223450723 819.6427327886199 L89.99704534667184 820.582349048617 L97.9868688183831 827.868230079955 L95.58699531374903 838.6969288056217 L104.63042156624942 832.9514039003169 L113.67384851652359 838.6969288056217 L111.28860819971018 827.868230079955 L119.26379778582702 820.582349048617 Z M104.63042156624942 830.0709380254297 L99.12827212164373 833.5675447348331 L100.5916097436015 826.9748233358861 L95.73332893639005 822.538599631987 L102.14274788803074 821.9532645905489 L104.63042156624942 815.7456333248583 L107.1327289556191 821.9686690478977 L113.54214790725979 822.5540040893358 L108.68386710004836 826.9902277932348 L110.14720472200611 833.5829491921818 L104.63042156624942 830.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_18" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="128.68" dataY="809.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.266752439155184" height="29.266752439155088" viewBox="128.68183456354723 809.4301763664666 29.266752439155184 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_18-667fa" d="M157.94858700270242 820.582349048617 L147.42718941709327 819.6273286985205 L143.31521078312483 809.4301763664666 L139.2032314513826 819.6427327886199 L128.68183456354723 820.582349048617 L136.6716580352585 827.868230079955 L134.27178453062442 838.6969288056217 L143.31521078312483 832.9514039003169 L152.35863773339898 838.6969288056217 L149.97339741658556 827.868230079955 L157.94858700270242 820.582349048617 Z M143.31521078312483 830.0709380254297 L137.8130613385191 833.5675447348331 L139.27639896047688 826.9748233358861 L134.41811815326545 822.538599631987 L140.82753710490613 821.9532645905489 L143.31521078312483 815.7456333248583 L145.8175181724945 821.9686690478977 L152.22693712413516 822.5540040893358 L147.36865631692373 826.9902277932348 L148.8319939388815 833.5829491921818 L143.31521078312483 830.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_18-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_19" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="167.37" dataY="809.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.2667524391551" height="29.266752439155088" viewBox="167.36662378042263 809.4301763664666 29.2667524391551 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_19-667fa" d="M196.6333762195777 820.582349048617 L186.11197863396862 819.6273286985205 L182.00000000000017 809.4301763664666 L177.88802066825798 819.6427327886199 L167.36662378042263 820.582349048617 L175.35644725213388 827.868230079955 L172.9565737474998 838.6969288056217 L182.00000000000017 832.9514039003169 L191.0434269502743 838.6969288056217 L188.6581866334609 827.868230079955 L196.6333762195777 820.582349048617 Z M182.00000000000017 830.0709380254297 L176.49785055539448 833.5675447348331 L177.96118817735226 826.9748233358861 L173.10290737014083 822.538599631987 L179.5123263217815 821.9532645905489 L182.00000000000017 815.7456333248583 L184.50230738936983 821.9686690478977 L190.9117263410105 822.5540040893358 L186.05344553379908 826.9902277932348 L187.51678315575683 833.5829491921818 L182.00000000000017 830.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_19-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_20" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="206.05" dataY="809.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.266752439155056" height="29.266752439155088" viewBox="206.05141299729797 809.4301763664666 29.266752439155056 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_20-667fa" d="M235.31816543645303 820.582349048617 L224.79676785084393 819.6273286985205 L220.68478921687552 809.4301763664666 L216.57280988513332 819.6427327886199 L206.05141299729797 820.582349048617 L214.04123646900922 827.868230079955 L211.64136296437513 838.6969288056217 L220.68478921687552 832.9514039003169 L229.7282161671496 838.6969288056217 L227.34297585033622 827.868230079955 L235.31816543645303 820.582349048617 Z M220.68478921687552 830.0709380254297 L215.18263977226982 833.5675447348331 L216.64597739422757 826.9748233358861 L211.78769658701617 822.538599631987 L218.19711553865682 821.9532645905489 L220.68478921687552 815.7456333248583 L223.18709660624518 821.9686690478977 L229.59651555788582 822.5540040893358 L224.7382347506744 826.9902277932348 L226.20157237263217 833.5829491921818 L220.68478921687552 830.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_20-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_21" class="path firer click commentable non-processed" customid="Star_outline"   datasizewidth="29.27px" datasizeheight="29.27px" dataX="244.74" dataY="809.43"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="29.26675243915497" height="29.266752439155088" viewBox="244.73620221417326 809.4301763664666 29.26675243915497 29.266752439155088" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_21-667fa" d="M274.00295465332823 820.582349048617 L263.48155706771917 819.6273286985205 L259.36957843375075 809.4301763664666 L255.25759910200858 819.6427327886199 L244.73620221417326 820.582349048617 L252.72602568588448 827.868230079955 L250.32615218125042 838.6969288056217 L259.36957843375075 832.9514039003169 L268.4130053840248 838.6969288056217 L266.0277650672114 827.868230079955 L274.00295465332823 820.582349048617 Z M259.36957843375075 830.0709380254297 L253.86742898914508 833.5675447348331 L255.33076661110283 826.9748233358861 L250.47248580389143 822.538599631987 L256.8819047555321 821.9532645905489 L259.36957843375075 815.7456333248583 L261.8718858231204 821.9686690478977 L268.28130477476105 822.5540040893358 L263.4230239675496 826.9902277932348 L264.8863615895074 833.5829491921818 L259.36957843375075 830.0709380254297 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_21-667fa" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_17" class="richtext autofit firer ie-background commentable non-processed" customid="Calificar y opinar:"   datasizewidth="123.60px" datasizeheight="18.00px" dataX="32.99" dataY="784.43" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_17_0">Calificar y opinar:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_18" class="richtext autofit firer ie-background commentable non-processed" customid="Rese&ntilde;as"   datasizewidth="72.32px" datasizeheight="22.00px" dataX="26.54" dataY="748.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_18_0">Rese&ntilde;as</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="20.00px" datasizeheight="20.00px" datasizewidthpx="20.0" datasizeheightpx="20.0" dataX="80.00" dataY="860.01" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="10.0" cy="10.0" rx="10.0" ry="10.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="10.0" cy="10.0" rx="10.0" ry="10.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Text_19" class="richtext manualfit firer ie-background commentable non-processed" customid="Luis Quispe Huam&aacute;n"   datasizewidth="101.42px" datasizeheight="14.00px" dataX="104.63" dataY="863.01" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_19_0">Luis Quispe Huam&aacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_20" class="richtext manualfit firer ie-background commentable non-processed" customid="El sitio est&aacute; bien para p"   datasizewidth="307.39px" datasizeheight="44.00px" dataX="30.03" dataY="888.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_20_0">El sitio est&aacute; bien para pasar un rato, pero hace un calor insoportable dentro. Necesitan mejorar la ventilaci&oacute;n o el aire acondicionado porque no se puede disfrutar al 100% as&iacute;.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="200.00px" datasizeheight="23.00px" datasizewidthpx="199.9999999999999" datasizeheightpx="23.0" dataX="83.72" dataY="1064.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 7"   datasizewidth="316.73px" datasizeheight="88.00px" datasizewidthpx="316.73480962950987" datasizeheightpx="88.0" dataX="20.68" dataY="850.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;