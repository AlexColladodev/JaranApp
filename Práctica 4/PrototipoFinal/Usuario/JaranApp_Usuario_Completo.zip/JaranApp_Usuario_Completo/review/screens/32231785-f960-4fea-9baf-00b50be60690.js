var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-32231785-f960-4fea-9baf-00b50be60690" class="screen growth-both devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Registro"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/32231785-f960-4fea-9baf-00b50be60690/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/32231785-f960-4fea-9baf-00b50be60690/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="JaranAppHorizontal"   datasizewidth="191.08px" datasizeheight="108.00px" dataX="84.00" dataY="54.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/974501e6-c08e-4287-8205-946f38ee9e78.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="137.00px" datasizeheight="134.10px" datasizewidthpx="136.99999999999977" datasizeheightpx="134.100529100529" dataX="112.00" dataY="149.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="68.49999999999989" cy="67.0502645502645" rx="68.49999999999989" ry="67.0502645502645">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="68.49999999999989" cy="67.0502645502645" rx="68.49999999999989" ry="67.0502645502645">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Input_text_1" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="30.00" dataY="305.05" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Correo Electr&oacute;nico"/></div></div>  </div></div></div>\
      <div id="s-Input_text_2" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="30.00" dataY="365.70" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Nombre Completo"/></div></div>  </div></div></div>\
      <div id="s-Input_text_3" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="30.00" dataY="426.35" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Nombre de Usuario"/></div></div>  </div></div></div>\
      <div id="s-Input_text_4" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="30.00" dataY="487.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Contrase&ntilde;a"/></div></div>  </div></div></div>\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Preferencias:"   datasizewidth="94.27px" datasizeheight="18.00px" dataX="30.00" dataY="555.93" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Preferencias:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="en_vivo"   datasizewidth="47.38px" datasizeheight="47.38px" dataX="38.00" dataY="585.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/0df351b8-af47-4acd-ae7f-19d2c89c4e81.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="En vivo"   datasizewidth="39.35px" datasizeheight="13.00px" dataX="42.01" dataY="632.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">En vivo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="deportes"   datasizewidth="47.38px" datasizeheight="47.38px" dataX="116.87" dataY="585.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/eb6499d0-5c95-41d2-ae54-6e9e8be408f3.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="chill"   datasizewidth="47.38px" datasizeheight="47.38px" dataX="195.75" dataY="585.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/ef47e134-7ff3-42b8-98fe-a53c7094a213.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="image firer ie-background commentable non-processed" customid="discoteca"   datasizewidth="47.38px" datasizeheight="47.38px" dataX="274.62" dataY="585.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/1e024554-d233-4de4-99b0-29800f36504f.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_6" class="image firer ie-background commentable non-processed" customid="latino"   datasizewidth="47.38px" datasizeheight="47.38px" dataX="42.01" dataY="669.84"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/bbfd3822-13c4-48c4-b0b2-0e214f4a5146.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_7" class="image firer ie-background commentable non-processed" customid="karaoke"   datasizewidth="47.38px" datasizeheight="47.38px" dataX="120.89" dataY="669.84"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/51437bd9-b021-40f8-8de0-dc3b093bca08.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_8" class="image firer ie-background commentable non-processed" customid="rock"   datasizewidth="47.38px" datasizeheight="47.38px" dataX="278.63" dataY="669.84"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/a11a031f-ef8d-43dd-ac48-9447bee394aa.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_9" class="image firer ie-background commentable non-processed" customid="bar"   datasizewidth="47.38px" datasizeheight="47.38px" dataX="199.76" dataY="669.84"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/1b05d295-30cc-44f6-83c9-a26801b31911.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="Deportes"   datasizewidth="48.69px" datasizeheight="13.00px" dataX="116.22" dataY="632.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Deportes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext autofit firer ie-background commentable non-processed" customid="Chill"   datasizewidth="23.34px" datasizeheight="13.00px" dataX="214.00" dataY="632.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Chill</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Discoteca"   datasizewidth="61.35px" datasizeheight="26.00px" dataX="272.00" dataY="632.38" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">Discoteca</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_6" class="richtext autofit firer ie-background commentable non-processed" customid="Latino"   datasizewidth="32.70px" datasizeheight="13.00px" dataX="52.68" dataY="717.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">Latino</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="richtext autofit firer ie-background commentable non-processed" customid="Karaoke"   datasizewidth="44.70px" datasizeheight="13.00px" dataX="120.21" dataY="717.23" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Karaoke</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_8" class="richtext autofit firer ie-background commentable non-processed" customid="Bar"   datasizewidth="18.67px" datasizeheight="13.00px" dataX="214.11" dataY="717.23" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_8_0">Bar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_9" class="richtext autofit firer ie-background commentable non-processed" customid="Rock"   datasizewidth="27.34px" datasizeheight="13.00px" dataX="289.01" dataY="717.23" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_9_0">Rock</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Crear Cuenta"   datasizewidth="274.33px" datasizeheight="29.00px" dataX="43.00" dataY="835.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Crear Cuenta</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="200.00px" datasizeheight="23.00px" datasizewidthpx="199.9999999999999" datasizeheightpx="23.0" dataX="79.00" dataY="962.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_2" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="26.00px" datasizeheight="26.78px" datasizewidthpx="26.0" datasizeheightpx="26.782675498216975" dataX="213.13" dataY="241.20" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_2)">\
                          <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="13.0" cy="13.391337749108487" rx="13.0" ry="13.391337749108487">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                          <ellipse cx="13.0" cy="13.391337749108487" rx="13.0" ry="13.391337749108487">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_2" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_2_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Path_102" class="path firer commentable non-processed" customid="Edit Outline"   datasizewidth="12.00px" datasizeheight="12.00px" dataX="220.13" dataY="248.59"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="11.999999999999943" height="11.999999488393541" viewBox="220.12627746436476 248.5887799921134 11.999999999999943 11.999999488393541" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_102-32231" d="M227.52627740318718 252.5887798215779 L228.12627712329373 253.18877954168443 L222.05961077885087 259.25544620401877 L221.45961074085292 259.25544620401877 L221.45961074085292 258.65544624549364 L227.52627740318718 252.5887798215779 M229.926277555179 248.5887799921134 C229.79294422554338 248.5887799921134 229.59294423605698 248.65544665693122 229.45961091635544 248.7887799915339 L228.25961099930524 249.98877990858412 L230.7929441928436 252.5221131021225 L231.92627746991127 251.25544654508974 C232.19294412918254 250.98877988581845 232.19294412918254 250.58877990684564 231.92627746991127 250.32211326744257 L230.392944233739 248.78878003127033 C230.25961087430105 248.6554465923595 230.05961011988842 248.5887799921134 229.926277555179 248.5887799921134 Z M227.52627740318718 250.7221131073379 L220.12627746436476 258.05544676380566 L220.12627746436476 260.5887794805069 L222.65961065790313 260.5887794805069 L229.99294320175085 253.18877954168443 C229.99294320175085 253.18877954168443 227.52627740318718 250.7221131073379 227.52627740318718 250.7221131073379 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_102-32231" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_117" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="25.00px" datasizeheight="25.00px" dataX="17.50" dataY="41.50"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="25.0" viewBox="17.500000000000476 41.5 25.0 25.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_117-32231" d="M42.500000000000476 52.4375 L23.484374880791187 52.4375 L32.218750119209766 43.70312476158142 L30.000000000000476 41.5 L17.500000000000476 54.0 L30.000000000000476 66.5 L32.20312494784641 64.29687505215406 L23.484374880791187 55.5625 L42.500000000000476 55.5625 L42.500000000000476 52.4375 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_117-32231" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_11" class="richtext manualfit firer ie-background commentable non-processed" customid="Al continuar, confirmas q"   datasizewidth="248.63px" datasizeheight="58.00px" dataX="80.36" dataY="763.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_11_0">Al continuar, confirmas que aceptas nuestros </span><span id="rtr-s-Text_11_1">T&eacute;rminos y Condiciones</span><span id="rtr-s-Text_11_2"> y nuestra </span><span id="rtr-s-Text_11_3">Pol&iacute;tica de Privacidad</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Check_1" class="inputAndroid checkbox firer commentable non-processed unchecked" customid="Check 1"  datasizewidth="16.00px" datasizeheight="16.00px" dataX="52.68" dataY="763.00"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Text_10" class="richtext manualfit firer ie-background commentable non-processed" customid="Tienes una cuenta?"   datasizewidth="145.65px" datasizeheight="18.00px" dataX="67.71" dataY="934.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_10_0">Tienes una cuenta?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_12" class="richtext manualfit firer ie-background commentable non-processed" customid="Inicia sesi&oacute;n"   datasizewidth="88.05px" datasizeheight="18.00px" dataX="213.36" dataY="934.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_12_0">Inicia sesi&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="94.02px" datasizeheight="18.00px" dataX="207.38" dataY="934.00"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-32231" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-32231" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-32231" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-32231" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_3" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-32231" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-32231" fill="#FFFFFF" fill-opacity="0.3"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_4" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_4-32231" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-32231" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_13" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_13_0">9:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;