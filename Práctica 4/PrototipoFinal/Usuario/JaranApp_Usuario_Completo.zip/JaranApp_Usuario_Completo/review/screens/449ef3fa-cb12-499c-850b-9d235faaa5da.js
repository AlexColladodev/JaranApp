var content='<div class="ui-page " deviceName="androidgalaxys23" deviceType="mobile" deviceWidth="360" deviceHeight="780">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device galaxy-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738010146959.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-449ef3fa-cb12-499c-850b-9d235faaa5da" class="screen growth-both devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="DetalleActividad"width="360" height="780">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/449ef3fa-cb12-499c-850b-9d235faaa5da/style-1738010146959.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/449ef3fa-cb12-499c-850b-9d235faaa5da/fonts-1738010146959.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.00px" datasizeheight="34.00px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.00" dataY="0.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="WiFi icon"   datasizewidth="15.00px" datasizeheight="11.92px" dataX="298.00" dataY="12.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.92010326500824" viewBox="298.0 12.000000000000012 15.0 11.92010326500824" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-449ef" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-449ef" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Signal icon"   datasizewidth="13.00px" datasizeheight="13.00px" dataX="313.00" dataY="11.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-449ef" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-449ef" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_3" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="7.70px" dataX="332.00" dataY="10.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="7.000000000000001" height="7.699999999999918" viewBox="332.0 10.000000000000007 7.000000000000001 7.699999999999918" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-449ef" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-449ef" fill="#FFFFFF" fill-opacity="0.3"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_4" class="path firer commentable non-processed" customid="Path"   datasizewidth="7.00px" datasizeheight="6.30px" dataX="332.00" dataY="18.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="6.999999916553178" height="6.299999999999841" viewBox="332.0 18.0 6.999999916553178 6.299999999999841" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_4-449ef" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-449ef" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_13" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.90px" datasizeheight="15.00px" dataX="23.00" dataY="9.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_13_0">9:30</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer click commentable non-processed" customid="Home"   datasizewidth="25.58px" datasizeheight="24.65px" dataX="30.35" dataY="735.17"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.58119658119638" height="24.649999999999864" viewBox="30.350000000000374 735.1749999999998 25.58119658119638 24.649999999999864" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-449ef" d="M40.582478632478924 759.8249999999997 L40.582478632478924 751.1249999999998 L45.698717948718205 751.1249999999998 L45.698717948718205 759.8249999999997 L52.094017094017296 759.8249999999997 L52.094017094017296 748.2249999999998 L55.93119658119676 748.2249999999998 L43.14059829059857 735.1749999999998 L30.350000000000374 748.2249999999998 L34.18717948717983 748.2249999999998 L34.18717948717983 759.8249999999997 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-449ef" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer click commentable non-processed" customid="Event"   datasizewidth="23.02px" datasizeheight="29.00px" dataX="217.09" dataY="733.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="23.02307692307693" height="29.0" viewBox="217.09273504273483 732.9999999999999 23.02307692307693 29.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-449ef" d="M234.99957264957246 748.9499999999999 L228.6042735042733 748.9499999999999 L228.6042735042733 756.1999999999999 L234.99957264957246 756.1999999999999 L234.99957264957246 748.9499999999999 Z M233.72051282051262 732.9999999999999 L233.72051282051262 735.8999999999999 L223.48803418803396 735.8999999999999 L223.48803418803396 732.9999999999999 L220.92991452991433 732.9999999999999 L220.92991452991433 735.8999999999999 L219.6508547008545 735.8999999999999 C218.23109827230098 735.8999999999999 217.10552562882737 737.2049999654292 217.10552562882737 738.7999999999998 L217.09273504273483 759.0999999999999 C217.09273504273483 760.6950000345706 218.23109827230098 761.9999999999999 219.6508547008545 761.9999999999999 L237.5576923076921 761.9999999999999 C238.96465815015307 761.9999999999999 240.11581196581176 760.6950000345706 240.11581196581176 759.0999999999999 L240.11581196581176 738.7999999999998 C240.11581196581176 737.2049999654292 238.96465815015307 735.8999999999999 237.5576923076921 735.8999999999999 L236.27863247863226 735.8999999999999 L236.27863247863226 732.9999999999999 L233.72051282051262 732.9999999999999 Z M237.5576923076921 759.0999999999999 L219.6508547008545 759.0999999999999 L219.6508547008545 743.1499999999999 L237.5576923076921 743.1499999999999 L237.5576923076921 759.0999999999999 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-449ef" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer commentable non-processed" customid="Search"   datasizewidth="22.37px" datasizeheight="25.36px" dataX="125.00" dataY="734.82"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.370756117502907" height="25.360499624907906" viewBox="125.00042735042783 734.8197501875461 22.370756117502907 25.360499624907906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-449ef" d="M140.98867521367572 750.769750187546 L139.97821792127283 750.769750187546 L139.62008116761132 750.3782501719893 C140.87355963389132 748.7252504087985 141.62820512820565 746.579249689728 141.62820512820565 744.2447501875461 C141.62820512820565 739.0392499662937 137.90614122081058 734.8197501875461 133.31431623931672 734.8197501875461 C128.7224912578229 734.8197501875461 125.00042735042783 739.0392499662937 125.00042735042783 744.2447501875461 C125.00042735042783 749.4502504087985 128.7224912578229 753.669750187546 133.31431623931672 753.669750187546 C135.37360258240017 753.669750187546 137.26661100132904 752.8142502255738 138.72473934063595 751.3932501114905 L139.07008550820493 751.799250113219 L139.07008550820493 752.9447501443327 L145.4653846535041 760.180249812454 L147.37118346793073 758.019750187546 L140.98867521367572 750.769750187546 Z M133.31431623931672 750.769750187546 C130.1294575577113 750.769750187546 127.55854700854749 747.8552498556674 127.55854700854749 744.2447501875461 C127.55854700854749 740.6342505194248 130.1294575577113 737.7197501875461 133.31431623931672 737.7197501875461 C136.49917492092214 737.7197501875461 139.07008547008598 740.6342505194248 139.07008547008598 744.2447501875461 C139.07008547008598 747.8552498556674 136.49917492092214 750.769750187546 133.31431623931672 750.769750187546 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-449ef" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer click commentable non-processed" customid="User"   datasizewidth="20.46px" datasizeheight="23.20px" dataX="309.19" dataY="735.90"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.46495726495732" height="23.199999999999704" viewBox="309.1850427350427 735.9000000000005 20.46495726495732 23.199999999999704" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-449ef" d="M319.4175213675214 747.5000000000005 C322.24424363853586 747.5000000000005 324.5337606837607 744.9045000553135 324.5337606837607 741.7000000000005 C324.5337606837607 738.4954999446874 322.24424363853586 735.9000000000005 319.4175213675214 735.9000000000005 C316.5907990965069 735.9000000000005 314.30128205128204 738.4954999446874 314.30128205128204 741.7000000000005 C314.30128205128204 744.9045000553135 316.5907990965069 747.5000000000005 319.4175213675214 747.5000000000005 Z M319.4175213675214 750.4000000000003 C316.0024315263471 750.4000000000003 309.1850427350427 752.3430000483993 309.1850427350427 756.2000000000003 L309.1850427350427 759.1000000000003 L329.65000000000003 759.1000000000003 L329.65000000000003 756.2000000000003 C329.65000000000003 752.3429998755458 322.83261120869565 750.4000000000003 319.4175213675214 750.4000000000003 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-449ef" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_9" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="15.34" dataY="45.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="15.337499999999968 45.00000000000004 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_9-449ef" d="M37.33749999999997 54.62500000000004 L20.603749895095795 54.62500000000004 L28.290000104904145 46.93874979019169 L26.33749999999997 45.00000000000004 L15.337499999999968 56.00000000000004 L26.33749999999997 67.00000000000004 L28.276249954104394 65.06125004589562 L20.603749895095795 57.37500000000004 L37.33749999999997 57.37500000000004 L37.33749999999997 54.62500000000004 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-449ef" fill="#666666" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_10" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="100.00px" datasizeheight="43.00px" datasizewidthpx="100.0" datasizeheightpx="42.99999999999977" dataX="18.68" dataY="370.02" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_10_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_13" class="path firer commentable non-processed" customid="Edit"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="271.34" dataY="45.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.000000000000004" viewBox="271.3375000000003 45.00000000000004 22.0 22.000000000000004" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_13-449ef" d="M271.3375000000003 62.41730312897374 L271.3375000000003 67.00000000000004 L275.92019708344714 67.00000000000004 L289.43609769557986 53.48409884892616 L284.853400612133 48.90140197789986 L271.3375000000003 62.41730312897374 Z M292.98004964060266 49.940147068175186 C293.4566501197995 49.46354661107005 293.4566501197995 48.69365354256483 292.98004964060266 48.217053085459696 L290.12044676542143 45.35745034282889 C289.6438462862246 44.88084988572376 288.8739531820327 44.88084988572376 288.39735270283586 45.35745034282889 L286.160996473669 47.593806468334535 L290.7436935571158 52.176503339360835 L292.9800497862827 49.9401472138552 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-449ef" fill="#666666" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_14" class="path firer commentable non-processed" customid="Share"   datasizewidth="22.00px" datasizeheight="22.00px" dataX="309.34" dataY="45.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="22.0" height="22.0" viewBox="309.3387495368723 45.00000000000004 22.0 22.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_14-449ef" d="M327.6720828702056 60.55020089547844 C326.74319399297275 60.55020089547844 325.9120828002695 60.88152620659717 325.276527268026 61.40060247249285 L316.5620826837093 56.81726907881679 C316.623193795731 56.56325301244479 316.6720826880803 56.309236946072794 316.6720826880803 56.04417673009202 C316.6720826880803 55.77911651411124 316.6231938002842 55.525100431282134 316.5620826837093 55.271084381367245 L325.17874958349637 50.731927651954734 C325.8387496097224 51.284136481876494 326.70652736127414 51.62650595906112 327.6720828702056 51.62650595906112 C329.70097171829843 51.62650595906112 331.3387495368723 50.14658625800689 331.3387495368723 48.31325297953058 C331.3387495368723 46.479919701054264 329.70097171829843 45.00000000000004 327.6720828702056 45.00000000000004 C325.64319402211277 45.00000000000004 324.00541620353897 46.479919701054264 324.00541620353897 48.31325297953058 C324.00541620353897 48.578313211968464 324.0543050913351 48.83232927834047 324.11541620790996 49.086345328255355 L315.4987494902482 53.62550271595208 C314.8387495368723 53.07329388603033 313.97097171247043 52.730923948046744 313.00541620353897 52.730923948046744 C310.97652735544614 52.730923948046744 309.3387495368723 54.210843649100966 309.3387495368723 56.04417692757728 C309.3387495368723 57.8775102060536 310.97652735544614 59.35742990710782 313.00541620353897 59.35742990710782 C313.97097178532056 59.35742990710782 314.8387495368723 59.015060429923196 315.4987494902482 58.46285160000144 L324.2009715725982 63.05722889642969 C324.1398604605765 63.28915659775571 324.10319379700593 63.53212849806181 324.10319379700593 63.7751003489966 C324.10319379700593 65.55321279714349 325.7043048381809 67.00000000000004 327.67208277914295 67.00000000000004 C329.6398605744048 67.00000000000004 331.24097176128004 65.55321292880032 331.24097176128004 63.7751003489966 C331.24097176128004 61.996987769192884 329.639860720105 60.55020069799316 327.67208277914295 60.55020069799316 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-449ef" fill="#666666" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_15" class="path firer commentable non-processed" customid="Add circle"   datasizewidth="27.25px" datasizeheight="27.25px" dataX="166.37" dataY="319.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="27.250000000000284" height="27.250000000000227" viewBox="166.37499999999983 319.0 27.250000000000284 27.250000000000227" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_15-449ef" d="M179.99999999999997 319.0 C172.47900002598752 319.0 166.37499999999983 325.10400002598766 166.37499999999983 332.6250000000001 C166.37499999999983 340.14599997401257 172.47900002598752 346.2500000000002 179.99999999999997 346.2500000000002 C187.52099997401243 346.2500000000002 193.6250000000001 340.14599997401257 193.6250000000001 332.6250000000001 C193.6250000000001 325.10400002598766 187.52100062370306 319.0 179.99999999999997 319.0 Z M186.81250000000006 333.9875000000001 L181.36249999999998 333.9875000000001 L181.36249999999998 339.43750000000017 L178.63749999999996 339.43750000000017 L178.63749999999996 333.9875000000001 L173.1874999999999 333.9875000000001 L173.1874999999999 331.2625000000001 L178.63749999999996 331.2625000000001 L178.63749999999996 325.81250000000006 L181.36249999999998 325.81250000000006 L181.36249999999998 331.2625000000001 L186.81250000000006 331.2625000000001 L186.81250000000006 333.9875000000001 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-449ef" fill="#999999" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Noche de Cine en casa de "   datasizewidth="316.76px" datasizeheight="25.00px" dataX="21.62" dataY="93.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Noche de Cine en casa de Carlos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_16" class="path firer commentable non-processed" customid="Location On"   datasizewidth="14.00px" datasizeheight="20.00px" dataX="21.62" dataY="129.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="20.0" viewBox="21.621994018555107 129.00000000000014 14.0 20.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_16-449ef" d="M28.621994018555107 129.00000000000014 C24.751994132996025 129.00000000000014 21.621994018555107 132.13000011444106 21.621994018555107 136.00000000000014 C21.621994018555107 141.25000000000014 28.621994018555107 149.00000000000014 28.621994018555107 149.00000000000014 C28.621994018555107 149.00000000000014 35.62199401855511 141.25000000000014 35.62199401855511 136.00000000000014 C35.62199401855511 132.13000011444106 32.49199390411419 129.00000000000014 28.621994018555107 129.00000000000014 Z M28.621994018555107 138.50000000000014 C27.24199402332348 138.50000000000014 26.121994018555107 137.37999999523177 26.121994018555107 136.00000000000014 C26.121994018555107 134.6200000047685 27.24199402332348 133.50000000000014 28.621994018555107 133.50000000000014 C30.001994013786735 133.50000000000014 31.121994018555107 134.6200000047685 31.121994018555107 136.00000000000014 C31.121994018555107 137.37999999523177 30.001994013786735 138.50000000000014 28.621994018555107 138.50000000000014 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-449ef" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Camino de Ronda, 122"   datasizewidth="147.09px" datasizeheight="16.00px" dataX="39.53" dataY="131.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Camino de Ronda, 122</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="31/01/2025 19:00"   datasizewidth="96.21px" datasizeheight="16.00px" dataX="248.45" dataY="131.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">31/01/2025 19:00</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Este viernes plan tranqui"   datasizewidth="297.15px" datasizeheight="72.00px" dataX="31.43" dataY="180.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Este viernes plan tranqui en casa de Carlos: peli, palomitas y sofazo. Caed sobre las 8 y traed algo para picar. Eso s&iacute;, nada de pelis raras, que os conozco.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 1"   datasizewidth="316.76px" datasizeheight="120.00px" datasizewidthpx="316.7560119628906" datasizeheightpx="120.00000000000003" dataX="21.62" dataY="171.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Actividad"   datasizewidth="86.39px" datasizeheight="20.00px" dataX="43.26" dataY="47.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">Actividad</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_6" class="richtext autofit firer ie-background commentable non-processed" customid="Participantes"   datasizewidth="127.75px" datasizeheight="25.00px" dataX="29.92" dataY="321.25" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">Participantes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_2" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="27.10px" datasizeheight="27.10px" datasizewidthpx="27.100732040405944" datasizeheightpx="27.100732040405944" dataX="29.92" dataY="377.45" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_2)">\
                          <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="13.550366020202972" cy="13.550366020202972" rx="13.550366020202972" ry="13.550366020202972">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                          <ellipse cx="13.550366020202972" cy="13.550366020202972" rx="13.550366020202972" ry="13.550366020202972">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_2" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_2_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Text_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Edwin"   datasizewidth="44.09px" datasizeheight="16.00px" dataX="63.34" dataY="383.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Edwin</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="100.00px" datasizeheight="43.00px" datasizewidthpx="100.0" datasizeheightpx="42.99999999999977" dataX="130.00" dataY="368.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_3" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="27.10px" datasizeheight="27.10px" datasizewidthpx="27.100732040405944" datasizeheightpx="27.100732040405944" dataX="141.25" dataY="375.93" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_3)">\
                          <ellipse id="s-Ellipse_3" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="13.550366020202972" cy="13.550366020202972" rx="13.550366020202972" ry="13.550366020202972">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                          <ellipse cx="13.550366020202972" cy="13.550366020202972" rx="13.550366020202972" ry="13.550366020202972">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_3" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_3_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Text_8" class="richtext manualfit firer ie-background commentable non-processed" customid="Miguel"   datasizewidth="44.09px" datasizeheight="16.00px" dataX="174.67" dataY="381.48" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_8_0">Miguel</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="100.00px" datasizeheight="43.00px" datasizewidthpx="100.0" datasizeheightpx="42.99999999999977" dataX="238.38" dataY="368.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_4" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="27.10px" datasizeheight="27.10px" datasizewidthpx="27.100732040405944" datasizeheightpx="27.100732040405944" dataX="249.63" dataY="375.93" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_4)">\
                          <ellipse id="s-Ellipse_4" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="13.550366020202972" cy="13.550366020202972" rx="13.550366020202972" ry="13.550366020202972">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                          <ellipse cx="13.550366020202972" cy="13.550366020202972" rx="13.550366020202972" ry="13.550366020202972">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_4" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_4_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Text_9" class="richtext manualfit firer ie-background commentable non-processed" customid="Luis"   datasizewidth="44.09px" datasizeheight="16.00px" dataX="283.04" dataY="381.48" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_9_0">Luis</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="rectangle manualfit firer click commentable non-processed" customid="BG"   datasizewidth="56.00px" datasizeheight="56.00px" datasizewidthpx="56.0" datasizeheightpx="56.0" dataX="279.56" dataY="642.72" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Messag"   datasizewidth="27.32px" datasizeheight="27.32px" dataX="293.90" dataY="657.06"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/21c437a3-5643-4b02-a56a-f95ce508dbb8.png" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;