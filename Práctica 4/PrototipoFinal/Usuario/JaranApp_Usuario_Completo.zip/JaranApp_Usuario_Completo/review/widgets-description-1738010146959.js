	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_5", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Clear", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Home", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Event", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Search", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["User", "s-Path_9"]; 

	widgets.descriptionMap[["s-Input_7", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Date input", "s-Group_12"]; 

	widgets.descriptionMap[["s-Paragraph_6", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Date input", "s-Group_12"]; 

	widgets.descriptionMap[["s-Paragraph_7", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Date input", "s-Group_12"]; 

	widgets.descriptionMap[["s-Ellipse_1", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Date input", "s-Group_12"]; 

	widgets.descriptionMap[["s-Path_12", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Date input", "s-Group_12"]; 

	widgets.descriptionMap[["s-Hotspot_1", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_1", "4ffd4d39-045b-4131-a48d-1fe27d8bd287"]] = ["Date input", "s-Group_12"]; 

	widgets.descriptionMap[["s-Path_5", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["Clear", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["Home", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["Event", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["Search", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["User", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["Star outline", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["Star outline", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_13", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["Star outline", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["Star outline", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "1189be83-d238-44ef-8484-e2741b9b1679"]] = ["Star outline", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_5", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ["Home", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ["Event", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ["Search", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ["User", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ["Arrow back", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_13", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ["Edit", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ["Share", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ["Add circle", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "449ef3fa-cb12-499c-850b-9d235faaa5da"]] = ["Location on", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_129", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_129", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Location on", "s-Path_129"]; 

	widgets.descriptionMap[["s-Path_11", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Star", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_365", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_365", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Walk", "s-Path_365"]; 

	widgets.descriptionMap[["s-Path_1", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Star", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Walk", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Home", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Event", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Search", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["User", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Star", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Location on", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Star", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Location on", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_12", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Star", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Location on", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Star", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Location on", "s-Path_15"]; 

	widgets.descriptionMap[["s-Rectangle_16", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_16", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_17", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "4fd198ed-59ae-4a63-9437-39f7e5c081b1"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_22", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ["Euro", "s-Path_22"]; 

	widgets.descriptionMap[["s-Path_3", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ["Home", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ["Event", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ["Search", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ["User", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_1", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "fbf73125-c0bb-4e96-b775-5131ea7dda66"]] = ["Share", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Location on", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_8", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Arrow back", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_70", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_70", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Favorite outline", "s-Path_70"]; 

	widgets.descriptionMap[["s-Path_52", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_52", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Bookmark outline", "s-Path_52"]; 

	widgets.descriptionMap[["s-Path_1", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Star", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_173", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_173", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Share", "s-Path_173"]; 

	widgets.descriptionMap[["s-Path_4", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Home", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Event", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Search", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["User", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_12", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Star", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Star", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Star", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Account circle", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Star outline", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Star outline", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_18", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Star outline", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Star outline", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "a7f04495-14b9-4cff-a1ac-d7e5eba837e6"]] = ["Star outline", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_22", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ["Euro", "s-Path_22"]; 

	widgets.descriptionMap[["s-Path_3", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ["Home", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ["Event", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ["Search", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ["User", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_1", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "57adc1c3-aa32-4e3d-9bf2-98b361db73cb"]] = ["Share", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_22", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ["Euro", "s-Path_22"]; 

	widgets.descriptionMap[["s-Path_3", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ["Home", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ["Event", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ["Search", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ["User", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_1", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "1149f5ba-d63e-4481-b8be-3fd1f69a47a6"]] = ["Share", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_4", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["Account circle", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_9", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["Clear", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_17", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["Arrow back", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_5", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["Account circle", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["Clear", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["Home", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["Event", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_10", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["Search", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["User", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_382", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_382", "bc18d88a-ac01-4bb9-9d7f-31c43ca48fbc"]] = ["Add user", "s-Path_382"]; 

	widgets.descriptionMap[["s-Path_102", "32231785-f960-4fea-9baf-00b50be60690"]] = ""; 

			widgets.rootWidgetMap[["s-Path_102", "32231785-f960-4fea-9baf-00b50be60690"]] = ["Edit outline", "s-Path_102"]; 

	widgets.descriptionMap[["s-Path_117", "32231785-f960-4fea-9baf-00b50be60690"]] = ""; 

			widgets.rootWidgetMap[["s-Path_117", "32231785-f960-4fea-9baf-00b50be60690"]] = ["Arrow back", "s-Path_117"]; 

	widgets.descriptionMap[["s-Path_1", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ["Share", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_11", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ["Home", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_12", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ["Event", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ["Search", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ["User", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_16", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "1b6cf767-c424-42c6-abc7-a45fd636baa9"]] = ["Edit", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_3", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Home", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Event", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Search", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["User", "s-Path_6"]; 

	widgets.descriptionMap[["s-Rectangle_16", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_16", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_17", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_191", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ""; 

			widgets.rootWidgetMap[["s-Path_191", "d11a9252-a8fb-4d39-8501-7bf5e7010e39"]] = ["Add", "s-Path_191"]; 

	widgets.descriptionMap[["s-Path_3", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Location on", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Home", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Event", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Search", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["User", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Arrow back", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_70", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_70", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Favorite outline", "s-Path_70"]; 

	widgets.descriptionMap[["s-Path_52", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_52", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Bookmark outline", "s-Path_52"]; 

	widgets.descriptionMap[["s-Path_1", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Star", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_173", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_173", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Share", "s-Path_173"]; 

	widgets.descriptionMap[["s-Path_12", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Star", "s-Path_12"]; 

	widgets.descriptionMap[["s-Path_13", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Star", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Star", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Account circle", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_17", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Star outline", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_18", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Star outline", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Star outline", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Star outline", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_21", "667faad0-092e-47b1-a674-178de97be8c5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "667faad0-092e-47b1-a674-178de97be8c5"]] = ["Star outline", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_143", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_143", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Email outline", "s-Path_143"]; 

	widgets.descriptionMap[["s-Path_239", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_239", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Lock outline", "s-Path_239"]; 

	widgets.descriptionMap[["s-Path_3", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Home", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Event", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Search", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["User", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_10", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Location on", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_13", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Location on", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_15", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Location on", "s-Path_15"]; 

	widgets.descriptionMap[["s-Rectangle_16", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_16", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_17", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "611cb570-4f7a-4d41-999c-3a379908ef12"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	